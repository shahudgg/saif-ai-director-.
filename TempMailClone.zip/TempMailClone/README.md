# Temp Mail — Clone (Kotlin + Jetpack Compose)

A from-scratch Android clone of the native app **"Temp Mail" 4.09**
(`com.tempmail`, versionCode 289), rebuilt in **Kotlin + Jetpack Compose** as an
openable Android Studio (Gradle KTS) project.

The feature set, screen map, Room schema, backend contract, billing SKUs and
user-facing copy were recovered by static analysis of the shipped APK
(`Temp Mail_4.09.apk`, see `../TempMailWork/` and `../rea-work/`). The clone talks
to the **same public backends** the original app uses.

> This is an independent reimplementation for study/educational use. It ships
> **none** of the original app's assets, signing keys, ad unit IDs or embedded
> credentials (the Adapty/AdMob/AppLovin/Start.io keys from the APK were
> deliberately **not** copied).

## Features

| Feature | Screen |
|---|---|
| Splash → onboarded check → mailbox | `SplashScreen` |
| 4-page onboarding | `OnboardingScreen` |
| Disposable address, copy, "Change" (regenerate) | `MailboxScreen` |
| Inbox list, unread badge, mailbox spinner, pull-to-refresh | `InboxScreen` |
| Message detail, HTML body, print, save `.eml`, show original | `MailScreen` |
| Manage / switch mailboxes, expiry status, delete | `SwitchMailboxScreen` |
| Custom email address (premium domains) | `CreateMailboxScreen` |
| Premium paywall (recovered SKUs) | `PremiumScreen` |
| Private domains + DNS(MX) help | `PrivateDomainsScreen` |
| Email addresses list | `EmailAddressesScreen` |
| Web-Premium QR pairing | `QrScreen` |
| Help Center, FAQ, Contact | `HelpScreens` |
| Navigation drawer (order + toggles mirror `drawer_layout.xml`) | `AppDrawer` |
| Bottom nav **Email / Inbox / Manage** | `AppBottomBar` |

## Architecture

```
app/src/main/java/com/tempmail/clone/
├─ App.kt                      # Application + manual AppContainer (service locator)
├─ MainActivity.kt             # Compose entry point (single activity)
├─ data/
│  ├─ local/                   # Room: EmailEntity / MailboxEntity / DomainEntity + Daos;
│  │                           #        DataStore PreferenceManager
│  ├─ remote/                  # Retrofit FreeApi (REST) + PremiumApi (JSON-RPC) + NetworkModule
│  └─ repository/              # Mailbox / Inbox / Mail / Domains / Subscription + Mappers
├─ ui/
│  ├─ AppRoot.kt               # NavHost graph + ModalNavigationDrawer
│  ├─ AppViewModel.kt          # single shared state holder (UiState)
│  ├─ Routes.kt                # named after the original nav destinations
│  ├─ theme/                   # Color / Type / Theme
│  ├─ components/              # AppToolbar, MenuRow, AppDrawer, AppBottomBar, HtmlContent, EmptyState
│  └─ screens/                 # one file per screen
└─ util/                       # Constants, AppUtils (ApiError/Resource), Exporter
```

- **UI:** Jetpack Compose + Material 3, `navigation-compose`
- **State:** one `AppViewModel` shared across screens (`ui/ViewModelFactory.kt`)
- **Persistence:** Room (inbox cache, mailboxes, domains) + DataStore (settings)
- **Network:** Retrofit + OkHttp + Gson; `zxing` for the QR screen; Coil available
- **minSdk 26 / targetSdk 35**, Kotlin 2.0.21, AGP 8.7.3, KSP, Gradle 8.11.1
- **Visual fidelity:** the Compose theme mirrors the original resources 1:1 — green
  `colorPrimary` `#18CA88`, `main_background` `#EAEEF2` (grey) / `#303234` (night),
  white `17dp`-radius mail cards (`mail_item.xml`), the 40dp circular-button toolbar
  (`toolbar_content.xml`), the amber Premium crown, the drawer "sheet" background and
  the 20sp/18sp/16sp/14sp/12sp type scale. Tokens live in `ui/theme/{Color,Dimens,Type}.kt`
  and `res/values{,-night}/{colors,themes}.xml`.

## UI map (original → clone)

| Original (View/XML) | Clone (Compose) |
|---|---|
| `SplashActivity` + `splash_screen_view` | `SplashScreen` |
| `SecondOnBoardingActivity` | `OnboardingScreen` |
| `MainActivity` + `activity_main.xml` + `drawer_layout.xml` | `MainActivity` → `AppRoot` → `AppDrawer` |
| `nav_mailbox` / `fragment_email_address.xml` | `Routes.MAILBOX` / `MailboxScreen` |
| `nav_inbox` / `fragment_inbox.xml` + `mail_item.xml` | `Routes.INBOX` / `InboxScreen` |
| `nav_mail` (arg `emailId`) / `fragment_mail.xml` | `Routes.MAIL` / `MailScreen` |
| `nav_switch_email` / `fragment_switch_email.xml` | `Routes.SWITCH` / `SwitchMailboxScreen` |
| `dialog_new_email.xml` | `CreateMailboxScreen` |
| `fragment_premium*.xml` | `PremiumScreen` |
| `fragment_private_domains.xml` + `dialog_dns_settings.xml` | `PrivateDomainsScreen` |
| `fragment_help_center.xml` / `fragment_faq.xml` / `fragment_contact_us.xml` | `HelpScreens` |
| `fragment_qr_code.xml` | `QrScreen` |
| `menu/bottom_navigation_menu.xml` | `BottomTab` (Email / Inbox / Manage) |

## Backend contract (same as the original)

**Free REST** — base `https://mob2.temp-mail.org`, `Authorization: Bearer <free token>`, 60 s timeout:

| Purpose | Endpoint |
|---|---|
| Create / re-issue mailbox | `POST /mailbox` → `{ mailbox, token }` |
| Validate token | `GET /mailbox` → `{ mailbox }` |
| List messages | `GET /messages?after=<seconds>` → `{ mailbox, messageCount, messages[] }` |
| One message | `GET /messages/{emailId}/` |
| Raw `.eml` source | `GET /messages/{emailId}/source` (`Accept: application/octet-stream`) |
| Attachment bytes | `GET /messages/{emailId}/attachment/{attachmentId}/` (`Accept: application/octet-stream`) |

**Premium JSON-RPC** — base `https://papi2.temp-mail.org`, `POST /rpc/` with
`{ id:1, jsonrpc:"2.0", method, params }`, 10 s timeout:

| Method | Params |
|---|---|
| `getdomains` | `sid` |
| `domain.add` / `domain.delete` | `sid, domain` |
| `domain.get` | `sid` |
| `mailbox.listv2` | `sid, lastCheck` |
| `mailbox.messages` | `sid, lastCheck, email` |
| `mailbox.new` | `sid, email, domain` |
| `mailbox.delete` | `sid, email` |
| `mail.get` | `sid, mail` |
| `mail.source` | `sid, mail, base64=true` |
| `mail.attachment` | `sid, attachmentName, mail, _id` |
| `firebase.token` | `sid, firebaseToken, pushEnabled` |
| `push.update` | `sid, enabled` |
| `user.verify_ots` | `sid, ots` |

Both clients add `User-Agent: <versionName>` and a default `Accept: application/json`
(mirrors the original `ApiClient`). Model field names (`@SerializedName`) match the
original DTOs so the same JSON parses unchanged.

## Free vs Premium limits

| | Free | Premium |
|---|---|---|
| Mailbox lifetime | **10 minutes** (`Constants.MAILBOX_LIFETIME_MS = 600000`) | 30 days |
| Message storage | up to **1 hour** | **30 days** / "30+ days" |
| Mailboxes per account | 1 | multiple |
| Custom / private domains | — | yes |
| Ads | yes (original) | ad-free |

## Setup

1. **Open in Android Studio** (Ladybug or newer). The Gradle wrapper
   (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, Gradle 8.11.1)
   is already included — first sync downloads dependencies.
2. Create `local.properties` (copy `local.properties.example`) and set
   `sdk.dir` to your Android SDK.
3. Build & run from Android Studio, or:
   ```bash
   ./gradlew assembleDebug
   ```
   (Do this on a workstation / CI — see the note below.)

> **Build not possible on the analysis device.** This project was authored on an
> Android/Linux device with no Android SDK, JDK build toolchain or Gradle
> Android plugin, so it has **not been compiled here**. Build it in Android
> Studio or CI.

## Notes / known gaps

- **Billing is stubbed.** `SubscriptionRepository.plans` lists the recovered Play
  SKUs (`subscription_one_week`, `subscription_monthly_trial`,
  `subscription_monthly`, `subscription_three_months`, `subscription_six_month`,
  `subscription_annual`). `PremiumScreen`'s button flips a local `is_premium`
  flag so the premium-only screens can be explored. Wire a real
  `BillingClient`/RevenueCat implementation in `SubscriptionRepository.activate`
  to make it live.
- **Ads, Firebase push and Analytics are excluded** (AdMob/AppLovin/Start.io/SafeDK
  and the Firebase config from the APK are not included). The premium RPC methods
  `firebase.token` / `push.update` are implemented but unused.
- **Premium session (`sid`).** Premium screens require a `sid`. The original
  obtains it after a Play purchase (`user.activation`) or `user.verify_ots` QR
  pairing; the clone can read/write `sid` in DataStore but does not perform the
  purchase, so premium calls return a "Premium session required" error until a
  `sid` is present.
- **Language switching** only stores the preference; Android per-app locale
  wiring is not implemented.
- **Lottie animations from the original are not redistributed.** The original
  shipped `@raw/*.json` Lottie tracks (`fire`, `owl`, `mail_flag`,
  `envelope_inbox_new`, `icon_gift`, `shredder`…). The clone deliberately ships
  **no Lottie runtime and no `.json` assets**; every animation is a native
  Compose re-creation that keeps the original timings/triggers (see below).
- The clone is **Kotlin + Compose** whereas the original is Kotlin/Java with
  View/XML, Hilt and a `NavHostFragment` graph — the *behaviour* and *screens*
  match, the implementation does not.

## Animation layer

All motion is reproduced in `ui/anim/` with the exact durations/easings recovered
from the decompiled sources. Everything is gated behind the **Animations** drawer
toggle (`UiState.animations`, mirroring `AppUtils.u(context)`).

| File | Reproduces |
| --- | --- |
| `ui/anim/Motion.kt` | Timing tokens (`MotionTiming`) + `ScreenFade`, `StaggeredItem`, `PulseAnimation`, `ShakeAnimation`, `NewMessagePill`. |
| `ui/anim/OwlRefresher.kt` | `CustomSwipeRefreshLayout` owl pull-to-refresh: 125dp reveal, 300ms translate, looping vector owl in place of `@raw/owl`. |
| `ui/anim/Overlays.kt` | Full-screen fire sweep (`FireOverlay`) with the address swap fired at **75%** (`MailboxFragmentPresenter`), plus `rememberBounceOnChange` (0ms→0.9, 250ms→1.0). |

Recovered timings: `fade_in/out` **250ms**; nav `config_navAnimTime` **150ms**;
copy press **200ms** then revert after **1500ms** with a **200ms** scale-back;
`scaleDownAndUpAnimation` **250ms**; `pulse_animation` **500ms ×2**;
`shape_animation` **50ms ×4**; pull-to-refresh translate **300ms** / min **1500ms**;
spinner **300ms**.

Where each is wired: `ui/AppRoot.kt` (NavHost cross-fade), `MailboxScreen.kt`
(copy button + envelope bounce + fire + pill), `InboxScreen.kt` (owl refresh,
staggered rows, empty-state Refresh drop-in, 500ms duplicate-tap guard),
`MailScreen.kt` (body fade), `AppBottomBar.kt` (`pulse_animation` + haptic on the
unread badge, tint cross-fade), `AppDrawer.kt` (staggered rows), `SplashScreen.kt`
(logo scale-up).
