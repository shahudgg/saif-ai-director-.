@rem ----------------------------------------------------------------------------
@rem Gradle start up script for Windows (Gradle 8.x)
@rem Requires gradle\wrapper\gradle-wrapper.jar (see gradlew notes).
@rem ----------------------------------------------------------------------------
@if "%DEBUG%"=="" @echo off
setlocal

set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%

set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar

if defined JAVA_HOME (
  set JAVACMD=%JAVA_HOME%\bin\java.exe
) else (
  set JAVACMD=java.exe
)

if not exist "%CLASSPATH%" (
  echo gradle-wrapper.jar is missing. Run "gradle wrapper" or open the project in Android Studio. 1>&2
  exit /b 1
)

"%JAVACMD%" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*

endlocal
