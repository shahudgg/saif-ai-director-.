package com.tempmail.clone.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.tempmail.clone.util.Constants
import java.util.Calendar

/**
 * Room entities recovered from `com.tempmail.data.db.*`.
 * Field sets and helper semantics mirror the originals
 * (EmailTable / MailboxTable / DomainTable).
 */

@Entity(tableName = "email_table")
data class EmailEntity(
    @PrimaryKey val eid: String,
    val emailAddress: String,
    val isChecked: Boolean = false,
    val fromField: String? = null,
    val subject: String? = null,
    val timestampMs: Long = 0L,
    val isDeleted: Boolean = false,
    val preview: String? = null,
    val isDetailsLoaded: Boolean = false,
    val attachmentsCount: Int = 0,
)

@Entity(tableName = "mailbox_table")
data class MailboxEntity(
    @PrimaryKey val fullEmailAddress: String,
    val emailPrefix: String,
    val domain: String,
    val isDefault: Boolean = false,
    val isPremium: Boolean = false,
    val startTime: Long = 0L,
    val endTime: Long = 0L,
) {
    fun isExpiredTime(now: Long = Calendar.getInstance().timeInMillis): Boolean =
        endTime > 0L && now >= endTime

    fun isExpiredSoon(now: Long = Calendar.getInstance().timeInMillis): Boolean =
        endTime > 0L && now < endTime && (endTime - now) <= Constants.EXPIRE_SOON_THRESHOLD_MS
}

@Entity(tableName = "domain_table")
data class DomainEntity(
    @PrimaryKey val domain: String,
    val expirationTimestamp: Long = 0L,
    val type: String = "premium",
    val status: String? = null,
) {
    fun isPrivate(): Boolean = type == "private"

    fun isExpiredSoon(now: Long = Calendar.getInstance().timeInMillis): Boolean =
        expirationTimestamp > 0L && now < expirationTimestamp &&
            (expirationTimestamp - now) <= Constants.EXPIRE_SOON_THRESHOLD_MS

    fun isExpired(now: Long = Calendar.getInstance().timeInMillis): Boolean =
        expirationTimestamp > 0L && now >= expirationTimestamp
}
