package com.tempmail.clone.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Web
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tempmail.clone.ui.UiState
import com.tempmail.clone.ui.anim.StaggeredItem
import com.tempmail.clone.ui.theme.AppColors
import com.tempmail.clone.ui.theme.AppDimens

/**
 * Navigation drawer reconstructed from `res/layout/drawer_layout.xml`.
 * Item order, toggles, the amber Premium icon and the footer links mirror the
 * original. Drawer background = `background_sheeld` (20dp rounded sheet).
 */
@Composable
fun AppDrawer(
    state: UiState,
    onClose: () -> Unit,
    onPremium: () -> Unit,
    onCustomEmail: () -> Unit,
    onPrivateDomains: () -> Unit,
    onWebPremium: () -> Unit,
    onHelpCenter: () -> Unit,
    onRateUs: () -> Unit,
    onRestart: () -> Unit,
    onDarkMode: (Boolean) -> Unit,
    onAnimations: (Boolean) -> Unit,
    onNotifications: (Boolean) -> Unit,
    onAutofill: (Boolean) -> Unit,
    onLanguage: (String?) -> Unit,
) {
    ModalDrawerSheet(
        modifier = Modifier.width(320.dp),
        drawerShape = RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp),
        drawerContainerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.Email,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp),
                )
                Text(
                    text = "Temp Mail",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 10.dp),
                )
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Close",
                    tint = AppColors.GrayMain,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(AppDimens.SmallRadius))
                        .clickable(onClick = onClose)
                        .padding(10.dp),
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 14.dp),
            ) {
                val animate = state.animations
                if (animate) {
                    StaggeredItem(key = "premium", index = 0) {
                        MenuRow(
                            icon = Icons.Filled.WorkspacePremium,
                            label = "Premium",
                            iconTint = AppColors.SystemNeutral,
                            trailing = if (state.isPremium) "ACTIVE" else null,
                            onClick = onPremium,
                        )
                    }
                    StaggeredItem(key = "custom", index = 1) {
                        MenuRow(Icons.Filled.Email, "Custom Email Address", onClick = onCustomEmail)
                    }
                    StaggeredItem(key = "domains", index = 2) {
                        MenuRow(Icons.Filled.Domain, "Private domains", onClick = onPrivateDomains)
                    }
                    StaggeredItem(key = "web", index = 3) {
                        MenuRow(Icons.Filled.Web, "Web Premium", showDividerAbove = true, onClick = onWebPremium)
                    }
                    StaggeredItem(key = "lang", index = 4) {
                        MenuRow(Icons.Filled.Language, "Change language", onClick = { onLanguage("en") })
                    }
                    StaggeredItem(key = "dark", index = 5) {
                        MenuRow(Icons.Filled.DarkMode, "Dark mode", switch = state.darkMode == true, onToggle = onDarkMode)
                    }
                    StaggeredItem(key = "anims", index = 6) {
                        MenuRow(Icons.Filled.Animation, "Animations", switch = state.animations, onToggle = onAnimations)
                    }
                    StaggeredItem(key = "notif", index = 7) {
                        MenuRow(Icons.Filled.Notifications, "Notifications", switch = state.notifications, onToggle = onNotifications)
                    }
                    StaggeredItem(key = "autofill", index = 8) {
                        MenuRow(Icons.Filled.Pin, "Autofill", switch = state.autofill, onToggle = onAutofill)
                    }
                    StaggeredItem(key = "help", index = 9) {
                        MenuRow(Icons.Filled.HelpOutline, "Help Center", showDividerAbove = true, onClick = onHelpCenter)
                    }
                    StaggeredItem(key = "rate", index = 10) {
                        MenuRow(Icons.Filled.Star, "Rate us", onClick = onRateUs)
                    }
                    StaggeredItem(key = "restart", index = 11) {
                        MenuRow(Icons.Filled.Autorenew, "RESTART", showDividerAbove = true, onClick = onRestart)
                    }
                } else {
                    MenuRow(
                        icon = Icons.Filled.WorkspacePremium,
                        label = "Premium",
                        iconTint = AppColors.SystemNeutral,
                        trailing = if (state.isPremium) "ACTIVE" else null,
                        onClick = onPremium,
                    )
                    MenuRow(Icons.Filled.Email, "Custom Email Address", onClick = onCustomEmail)
                    MenuRow(Icons.Filled.Domain, "Private domains", onClick = onPrivateDomains)

                    MenuRow(Icons.Filled.Web, "Web Premium", showDividerAbove = true, onClick = onWebPremium)
                    MenuRow(Icons.Filled.Language, "Change language", onClick = { onLanguage("en") })
                    MenuRow(Icons.Filled.DarkMode, "Dark mode", switch = state.darkMode == true, onToggle = onDarkMode)
                    MenuRow(Icons.Filled.Animation, "Animations", switch = state.animations, onToggle = onAnimations)
                    MenuRow(Icons.Filled.Notifications, "Notifications", switch = state.notifications, onToggle = onNotifications)
                    MenuRow(Icons.Filled.Pin, "Autofill", switch = state.autofill, onToggle = onAutofill)

                    MenuRow(Icons.Filled.HelpOutline, "Help Center", showDividerAbove = true, onClick = onHelpCenter)
                    MenuRow(Icons.Filled.Star, "Rate us", onClick = onRateUs)
                    MenuRow(Icons.Filled.Autorenew, "RESTART", showDividerAbove = true, onClick = onRestart)
                }
            }

            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Terms",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.clickable { onHelpCenter() },
                )
                Text("·", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    text = "Privacy",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.clickable { onHelpCenter() },
                )
            }
            Text(
                text = "App version 4.09-clone",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .padding(start = 20.dp, bottom = 18.dp)
                    .alpha(0.6f),
            )
        }
    }
}
