package com.tempmail.clone.ui

/** Routes for the clone; named after the original navigation graph destinations. */
object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val MAILBOX = "mailbox"          // nav_mailbox  (Email address screen)
    const val INBOX = "inbox"              // nav_inbox
    const val MAIL = "mail"                // nav_mail (+ emailId arg)
    const val SWITCH = "switch"            // nav_switch_email (Manage)
    const val CREATE_MAILBOX = "create_mailbox"
    const val PREMIUM = "premium"
    const val PRIVATE_DOMAINS = "private_domains"
    const val HELP_CENTER = "help_center"
    const val FAQ = "faq"
    const val CONTACT = "contact"
    const val QR = "qr"
    const val EMAIL_ADDRESSES = "email_addresses"

    fun mail(emailId: String) = "$MAIL?emailId=$emailId"
}
