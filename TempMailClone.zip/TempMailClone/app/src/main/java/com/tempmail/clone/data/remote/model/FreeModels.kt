package com.tempmail.clone.data.remote.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

/**
 * Free-tier REST models — recovered from
 * `com.tempmail.data.api.models.answers.new_free.*`.
 * Served by https://mob2.temp-mail.org.
 */

open class BaseFreeWrapper {
    var errorMessage: String? = null
    var errorName: String? = null
}

/** POST /mailbox  →  { "mailbox": "...", "token": "..." } */
data class GetMailboxWrapper(
    @SerializedName("mailbox") var mailbox: String? = null,
    @SerializedName("token") var token: String? = null,
) : BaseFreeWrapper()

/** GET /mailbox  →  { "mailbox": "..." } (validates the stored token) */
data class VerifyMailboxWrapper(
    @SerializedName("mailbox") var mailbox: String? = null,
) : BaseFreeWrapper()

/** GET /messages?after=<id>  →  the free inbox page. */
data class GetMessagesWrapper(
    @SerializedName("mailbox") var mailbox: String? = null,
    @SerializedName("messageCount") var messageCount: Int? = null,
    @SerializedName("messages") var messages: List<MailFree>? = null,
) : BaseFreeWrapper() {
    override fun toString(): String =
        "GetMessagesWrapper(mailbox=$mailbox, messageCount=$messageCount, messages=${messages?.size})"
}

/**
 * One free message. Field names match the original `MailFree` exactly so the
 * same JSON parses unchanged.
 */
data class MailFree(
    @SerializedName("_id") @Expose var mailId: String = "",
    @SerializedName("from") @Expose var mailFrom: String = "",
    @SerializedName("subject") @Expose var mailSubject: String = "",
    @SerializedName("receivedAt") @Expose var mailTimestamp: Double = 0.0,
    @SerializedName("bodyHtml") @Expose var mailHtml: String = "",
    @SerializedName("attachmentsCount") @Expose var attachmentsCount: Int = 0,
    @SerializedName("bodyPreview") var preview: String? = null,
    @SerializedName("attachments") var attachmentInfo: List<ExtendedMail.AttachmentInfo>? = null,
) {
    val attachmentCountOrZero: Int get() = attachmentsCount
}
