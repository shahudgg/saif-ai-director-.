package com.tempmail.clone.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EmailDao {
    @Query("SELECT * FROM email_table WHERE emailAddress = :address AND isDeleted = 0 ORDER BY timestampMs DESC")
    fun observeForMailbox(address: String): Flow<List<EmailEntity>>

    @Query("SELECT * FROM email_table WHERE eid = :eid LIMIT 1")
    suspend fun byId(eid: String): EmailEntity?

    @Query("SELECT * FROM email_table WHERE eid = :eid LIMIT 1")
    fun observeById(eid: String): Flow<EmailEntity?>

    @Query("SELECT COUNT(*) FROM email_table WHERE emailAddress = :address AND isChecked = 0 AND isDeleted = 0")
    fun observeUnreadCount(address: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM email_table WHERE emailAddress = :address AND isChecked = 0 AND isDeleted = 0")
    suspend fun unreadCount(address: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(email: EmailEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(emails: List<EmailEntity>)

    @Query("UPDATE email_table SET isChecked = :checked WHERE eid = :eid")
    suspend fun setChecked(eid: String, checked: Boolean)

    @Query("UPDATE email_table SET isDeleted = 1 WHERE eid = :eid")
    suspend fun markDeleted(eid: String)

    @Query("UPDATE email_table SET isDetailsLoaded = 1 WHERE eid = :eid")
    suspend fun markDetailsLoaded(eid: String)

    @Query("DELETE FROM email_table WHERE emailAddress = :address")
    suspend fun clearMailbox(address: String)

    @Query("DELETE FROM email_table WHERE isDeleted = 1 OR timestampMs < :olderThanMs")
    suspend fun purgeDeletedAndOld(olderThanMs: Long)
}

@Dao
interface MailboxDao {
    @Query("SELECT * FROM mailbox_table ORDER BY isDefault DESC, startTime ASC")
    fun observeMailboxes(): Flow<List<MailboxEntity>>

    @Query("SELECT * FROM mailbox_table ORDER BY isDefault DESC, startTime ASC")
    suspend fun mailboxes(): List<MailboxEntity>

    @Query("SELECT * FROM mailbox_table WHERE isDefault = 1 LIMIT 1")
    fun observeDefault(): Flow<MailboxEntity?>

    @Query("SELECT * FROM mailbox_table WHERE isDefault = 1 LIMIT 1")
    suspend fun defaultMailbox(): MailboxEntity?

    @Query("SELECT * FROM mailbox_table WHERE fullEmailAddress = :address LIMIT 1")
    suspend fun byAddress(address: String): MailboxEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(mailbox: MailboxEntity)

    @Query("UPDATE mailbox_table SET isDefault = 0")
    suspend fun clearDefaults()

    @Query("UPDATE mailbox_table SET isDefault = 1 WHERE fullEmailAddress = :address")
    suspend fun setDefault(address: String)

    @Query("DELETE FROM mailbox_table WHERE fullEmailAddress = :address")
    suspend fun delete(address: String)

    @Query("DELETE FROM mailbox_table")
    suspend fun clear()
}

@Dao
interface DomainDao {
    @Query("SELECT * FROM domain_table ORDER BY domain ASC")
    fun observeDomains(): Flow<List<DomainEntity>>

    @Query("SELECT * FROM domain_table WHERE type = 'private' ORDER BY domain ASC")
    fun observePrivateDomains(): Flow<List<DomainEntity>>

    @Query("SELECT * FROM domain_table ORDER BY domain ASC")
    suspend fun domains(): List<DomainEntity>

    @Query("SELECT * FROM domain_table WHERE type = 'private' ORDER BY domain ASC")
    suspend fun privateDomains(): List<DomainEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(domains: List<DomainEntity>)

    @Query("DELETE FROM domain_table")
    suspend fun clear()

    @Query("DELETE FROM domain_table WHERE type = 'private'")
    suspend fun clearPrivate()

    @Query("DELETE FROM domain_table WHERE domain = :domain")
    suspend fun delete(domain: String)
}
