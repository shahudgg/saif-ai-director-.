package com.tempmail.clone.util

import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Small self-contained error wrapper used across the repository layer.
 * Mirrors the original's `ApiError` (code / message / errorName / subCode).
 */
data class ApiError(
    val code: Int? = null,
    val message: String? = null,
    val errorName: String? = null,
    val subCode: Int? = null,
)

/** Network result wrapper (originally `com.tempmail.data.Resource`). */
sealed class Resource<out T> {
    data class Success<T>(val data: T) : Resource<T>()
    data class Error(val error: ApiError) : Resource<Nothing>()
    object Loading : Resource<Nothing>()
}

/** True when the device is a low-RAM phone (animations are disabled there). */
fun formatRelativeTime(timestampMs: Long): String {
    if (timestampMs <= 0L) return ""
    val now = Calendar.getInstance().timeInMillis
    val diff = now - timestampMs
    val minutes = TimeUnit.MILLISECONDS.toMinutes(diff)
    val hours = TimeUnit.MILLISECONDS.toHours(diff)
    val days = TimeUnit.MILLISECONDS.toDays(diff)
    return when {
        minutes < 1 -> "now"
        minutes < 60 -> "${minutes}m"
        hours < 24 -> "${hours}h"
        days < 7 -> "${days}d"
        else -> java.text.SimpleDateFormat("MMM d", Locale.getDefault()).format(timestampMs)
    }
}

/** Original `AppUtils.getUserInitials`: first letters of up to two words. */
fun userInitials(from: String?): String {
    val name = from?.trim().orEmpty()
    if (name.isEmpty()) return "?"
    val parts = name.split(Regex("[\\s._-]+")).filter { it.isNotBlank() }
    val initials = parts.take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("")
    return initials.ifEmpty { name.first().uppercaseChar().toString() }
}

/** Original `AppUtils.getFromEmail()` — extracts `name <mail@host>` or bare address. */
fun fromEmail(from: String?): String {
    if (from.isNullOrBlank()) return ""
    val lt = from.indexOf('<')
    val gt = from.indexOf('>')
    return if (lt >= 0 && gt > lt) from.substring(lt + 1, gt).trim() else from.trim()
}

/** Original `AppUtils.getFromName()` — display name part of a From header. */
fun fromName(from: String?): String {
    if (from.isNullOrBlank()) return ""
    val lt = from.indexOf('<')
    val name = if (lt > 0) from.substring(0, lt) else from
    return name.trim().trim('"').ifBlank { fromEmail(from) }
}
