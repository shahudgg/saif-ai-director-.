package com.tempmail.clone.data.remote

import com.tempmail.clone.BuildConfig
import com.tempmail.clone.util.Constants
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Builds the two Retrofit clients used by the app.
 *
 * Both add the headers the original `ApiClient` adds:
 *  - `User-Agent: <versionName>`
 *  - `Accept: application/json` (unless a call overrides it, e.g. octet-stream)
 */
object NetworkModule {

    private fun headerInterceptor(): Interceptor = Interceptor { chain ->
        val request = chain.request()
        val builder = request.headers.newBuilder()
            .add("User-Agent", BuildConfig.VERSION_NAME)
        if (request.header("Accept") == null) {
            builder.add("Accept", "application/json")
        }
        chain.proceed(request.newBuilder().headers(builder.build()).build())
    }

    private fun logging(): HttpLoggingInterceptor =
        HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BASIC
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }

    private fun client(timeoutSeconds: Long): OkHttpClient =
        OkHttpClient.Builder()
            .connectTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .readTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .writeTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .addInterceptor(headerInterceptor())
            .addInterceptor(logging())
            .build()

    private fun retrofit(baseUrl: String, timeoutSeconds: Long): Retrofit =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .client(client(timeoutSeconds))
            .build()

    /** Free REST client (60 s, like the original `ApiClient.e`). */
    val freeApi: FreeApi by lazy {
        retrofit(Constants.BASE_URL_FREE, 60L).create(FreeApi::class.java)
    }

    /** Premium JSON-RPC client (10 s, like the original `ApiClient.f`). */
    val premiumApi: PremiumApi by lazy {
        retrofit(Constants.BASE_URL_PREMIUM, 10L).create(PremiumApi::class.java)
    }
}
