package com.tempmail.clone.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/**
 * Saves a message's raw source as a `.eml` file.
 * Mirrors the original `MyFileUtils` / `DownloadMailService` behaviour
 * (files land in `Download/TempMail/`).
 */
object Exporter {

    private const val FOLDER = "TempMail"

    fun saveEml(context: Context, subject: String, source: String): Boolean {
        val safeName = subject.ifBlank { "message" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(48)
        val fileName = "$safeName.eml"
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "message/rfc822")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER")
                }
                val uri: Uri? = context.contentResolver.insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values,
                )
                uri?.let {
                    context.contentResolver.openOutputStream(it)?.use { stream ->
                        stream.write(source.toByteArray())
                    }
                }
                uri != null
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER)
                if (!dir.exists()) dir.mkdirs()
                File(dir, fileName).writeText(source)
                true
            }
        } catch (t: Throwable) {
            false
        }
    }

    /** Saves raw attachment bytes under `Download/TempMail/`. */
    fun saveAttachment(context: Context, fileName: String, bytes: ByteArray): Boolean {
        val name = fileName.ifBlank { "attachment.bin" }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                uri?.let {
                    context.contentResolver.openOutputStream(it)?.use { stream -> stream.write(bytes) }
                }
                uri != null
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER)
                if (!dir.exists()) dir.mkdirs()
                File(dir, name).writeBytes(bytes)
                true
            }
        } catch (t: Throwable) {
            false
        }
    }
}
