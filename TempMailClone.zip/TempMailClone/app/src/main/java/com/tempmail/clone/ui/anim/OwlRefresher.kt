package com.tempmail.clone.ui.anim

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseInOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshState
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.tempmail.clone.ui.theme.AppColors

/** Height of the owl reveal — matches `@dimen/owlAnimationHeight` (125dp). */
private val OwlHeight = 125.dp

/** `@dimen/owlAnimationHeight` translated to dp for the indicator offset. */
private val OwlSize = 72.dp

/**
 * Pull-to-refresh list with the original owl indicator.
 *
 * The original `CustomSwipeRefreshLayout` dragged the RecyclerView down by
 * `min(delta / 2, owlAnimationHeight)` and revealed a looping `@raw/owl` Lottie
 * animation from behind the top edge (300ms). We recreate the owl as a vector
 * drawing (no Lottie assets are redistributed) and keep the same 125dp reveal
 * and 300ms timing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwlRefreshableBox(
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    state: PullToRefreshState = rememberPullToRefreshState(),
    content: @Composable () -> Unit,
) {
    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = onRefresh,
        modifier = modifier,
        state = state,
        indicator = {
            OwlRefreshIndicator(
                state = state,
                isRefreshing = isRefreshing,
                modifier = Modifier.align(Alignment.TopCenter),
            )
        },
    ) {
        content()
    }
}

/**
 * The owl itself. While the user drags it tracks the pull; once refreshing it
 * loops: a gentle vertical bob (the `owl` Lottie loop) plus scanning pupils.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwlRefreshIndicator(
    state: PullToRefreshState,
    isRefreshing: Boolean,
    modifier: Modifier = Modifier,
) {
    val fraction = state.distanceFraction.coerceIn(0f, 1f)
    // Owl slides down from behind the top edge exactly like the Lottie view
    // (`translationY = -125dp` → `0`).
    val revealTarget = if (isRefreshing) 1f else fraction
    val reveal by animateFloatAsState(
        targetValue = revealTarget,
        animationSpec = tween(MotionTiming.REFRESH_TRANSLATE_MS, easing = MotionTiming.EaseOutCubic),
        label = "owlReveal",
    )

    val bob = rememberInfiniteTransition(label = "owlBob")
    val bobY by bob.animateFloat(
        initialValue = 0f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = EaseInOut),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "owlBobY",
    )
    val scan by bob.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "owlScan",
    )
    val blink = remember { Animatable(1f) }
    LaunchedEffect(isRefreshing) {
        if (isRefreshing) {
            while (true) {
                kotlinx.coroutines.delay(1600)
                blink.animateTo(0.1f, tween(80))
                blink.animateTo(1f, tween(120))
            }
        }
    }

    Box(
        modifier = modifier
            .size(OwlHeight)
            .graphicsLayer {
                translationY = -(1f - reveal) * OwlHeight.toPx()
                alpha = reveal
            },
        contentAlignment = Alignment.Center,
    ) {
        Owl(
            modifier = Modifier.size(OwlSize),
            scannerX = if (isRefreshing) scan else 0f,
            scannerY = if (isRefreshing) 0f else (fraction - 0.5f) * 0.6f,
            bob = if (isRefreshing) bobY else 0f,
            blink = blink.value,
            bodyColor = MaterialTheme.colorScheme.primaryContainer,
            eyeColor = Color.White,
            pupilColor = MaterialTheme.colorScheme.primary,
            beakColor = AppColors.SystemNeutral,
        )
    }
}

/**
 * Minimal vector stand-in for the original `@raw/owl` Lottie loop: a rounded
 * owl body, two ear tufts, big eyes with movable pupils and an amber beak.
 */
@Composable
private fun Owl(
    modifier: Modifier = Modifier,
    scannerX: Float = 0f,
    scannerY: Float = 0f,
    bob: Float = 0f,
    blink: Float = 1f,
    bodyColor: Color = Color(0xFFD6FFF0),
    eyeColor: Color = Color.White,
    pupilColor: Color = Color(0xFF18CA88),
    beakColor: Color = Color(0xFFFFB413),
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f + bob

        // Ear tufts.
        val ear = Path().apply {
            moveTo(cx - w * 0.30f, cy - h * 0.24f)
            lineTo(cx - w * 0.16f, cy - h * 0.46f)
            lineTo(cx - w * 0.04f, cy - h * 0.22f)
            close()
        }
        drawPath(ear, bodyColor)
        val ear2 = Path().apply {
            moveTo(cx + w * 0.30f, cy - h * 0.24f)
            lineTo(cx + w * 0.16f, cy - h * 0.46f)
            lineTo(cx + w * 0.04f, cy - h * 0.22f)
            close()
        }
        drawPath(ear2, bodyColor)

        // Body.
        drawOval(
            color = bodyColor,
            topLeft = Offset(cx - w * 0.36f, cy - h * 0.30f),
            size = Size(w * 0.72f, h * 0.78f),
        )

        // Eyes.
        val eyeR = w * 0.20f
        val eyeY = cy - h * 0.08f
        drawCircle(eyeColor, eyeR, Offset(cx - w * 0.18f, eyeY))
        drawCircle(eyeColor, eyeR, Offset(cx + w * 0.18f, eyeY))
        // Pupils (blink squashes them vertically).
        val pupilR = eyeR * 0.45f
        drawOval(
            color = pupilColor,
            topLeft = Offset(cx - w * 0.18f - pupilR + scannerX * eyeR * 0.5f, eyeY - pupilR * blink + scannerY * eyeR * 0.4f),
            size = Size(pupilR * 2f, pupilR * 2f * blink),
        )
        drawOval(
            color = pupilColor,
            topLeft = Offset(cx + w * 0.18f - pupilR + scannerX * eyeR * 0.5f, eyeY - pupilR * blink + scannerY * eyeR * 0.4f),
            size = Size(pupilR * 2f, pupilR * 2f * blink),
        )

        // Beak.
        val beak = Path().apply {
            moveTo(cx - w * 0.07f, cy + h * 0.10f)
            lineTo(cx, cy + h * 0.24f)
            lineTo(cx + w * 0.07f, cy + h * 0.10f)
            close()
        }
        drawPath(beak, beakColor)

        // A subtle outline so the owl reads on light and dark surfaces.
        drawOval(
            color = pupilColor.copy(alpha = 0.25f),
            topLeft = Offset(cx - w * 0.36f, cy - h * 0.30f),
            size = Size(w * 0.72f, h * 0.78f),
            style = Stroke(width = w * 0.03f),
        )
    }
}

/** Alias kept for parity with `@dimen/owlAnimationHeight`. */
internal val OwlIndicatorHeight = OwlHeight
