package com.tempmail.clone.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tempmail.clone.ui.components.AppToolbar

/** Help Center — mirrors `fragment_help_center.xml` (FAQ + Contact us). */
@Composable
fun HelpCenterScreen(
    onBack: () -> Unit,
    onFaq: () -> Unit,
    onContact: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        AppToolbar(title = "Help Center", onBack = onBack)
        Column(modifier = Modifier.padding(20.dp)) {
            HelpRow(Icons.Filled.QuestionAnswer, "FAQ", onFaq)
            Spacer(Modifier.height(10.dp))
            HelpRow(Icons.Filled.Email, "Contact Us", onContact)
        }
    }
}

@Composable
private fun HelpRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Icon(Icons.Filled.KeyboardArrowRight, contentDescription = null)
    }
}

private val FAQ_ITEMS = listOf(
    "What is the difference between Free and Premium?" to
        "Free emails last up to 1 hour and may be lost, while Premium offers multiple private mailboxes, 30+ days of storage, custom domain options, and additional benefits.",
    "How long are emails stored?" to
        "Free email messages are stored for up to 1 hour, while Premium emails last up to 30 days.",
    "How to delete a mailbox?" to
        "Tap Change to get a new address or delete it via the Inbox menu or by swiping left. Once deleted, the mailbox is permanently removed and cannot be accessed by anyone, including you.",
    "How to recover my email?" to
        "Temporary emails cannot be recovered for security reasons; upgrade to Premium for 30+ days of storage and additional benefits.",
    "How to send an email?" to
        "Sending emails from our addresses is not available due to fraud and spam risks, but you can reply or forward using your private email.",
    "How to open my Premium on the website?" to
        "Go to \"Web Premium\", scan the QR code, and log in to access Premium features on https://temp-mail.org",
    "Is Temp Mail anonymous and secure?" to
        "No personal data is required, emails are private, and deleted mailboxes cannot be restored.",
)

/** FAQ — mirrors `fragment_faq.xml` + `faq_item.xml`. */
@Composable
fun FaqScreen(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        AppToolbar(title = "FAQ", onBack = onBack)
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
        ) {
            FAQ_ITEMS.forEach { (q, a) ->
                Text(q, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(a, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

/** Contact form — mirrors `fragment_contact_us.xml`. */
@Composable
fun ContactScreen(onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        AppToolbar(title = "Contact Us", onBack = onBack)
        Column(modifier = Modifier.padding(20.dp)) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Enter Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                label = { Text("Message ( min 30 characters )") },
                minLines = 4,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { name = ""; message = "" },
                enabled = name.isNotBlank() && message.length >= 30,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Send") }
        }
    }
}
