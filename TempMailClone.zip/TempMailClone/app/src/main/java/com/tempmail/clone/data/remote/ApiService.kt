package com.tempmail.clone.data.remote

import com.tempmail.clone.data.remote.model.AddDomainBody
import com.tempmail.clone.data.remote.model.AddPrivateDomainWrapper
import com.tempmail.clone.data.remote.model.DeleteEmailBody
import com.tempmail.clone.data.remote.model.DeletePrivateDomainBody
import com.tempmail.clone.data.remote.model.DomainsBody
import com.tempmail.clone.data.remote.model.DomainsWrapper
import com.tempmail.clone.data.remote.model.EmptyResultWrapper
import com.tempmail.clone.data.remote.model.FirebaseTokenBody
import com.tempmail.clone.data.remote.model.GetAttachmentBody
import com.tempmail.clone.data.remote.model.GetAttachmentWrapper
import com.tempmail.clone.data.remote.model.GetMailBody
import com.tempmail.clone.data.remote.model.GetMailSourceBody
import com.tempmail.clone.data.remote.model.GetMailSourceWrapper
import com.tempmail.clone.data.remote.model.GetMailWrapper
import com.tempmail.clone.data.remote.model.GetMailboxWrapper
import com.tempmail.clone.data.remote.model.GetMessagesWrapper
import com.tempmail.clone.data.remote.model.GetPrivateDomainBody
import com.tempmail.clone.data.remote.model.GetPrivateDomainsWrapper
import com.tempmail.clone.data.remote.model.InboxListWrapper
import com.tempmail.clone.data.remote.model.MailFree
import com.tempmail.clone.data.remote.model.MailboxesBody
import com.tempmail.clone.data.remote.model.NewMailboxBody
import com.tempmail.clone.data.remote.model.NewMailboxWrapper
import com.tempmail.clone.data.remote.model.PremiumEmailsWrapper
import com.tempmail.clone.data.remote.model.PushUpdateBody
import com.tempmail.clone.data.remote.model.SidWrapper
import com.tempmail.clone.data.remote.model.SingleMailboxBody
import com.tempmail.clone.data.remote.model.VerifyMailboxWrapper
import com.tempmail.clone.data.remote.model.VerifyOtsBody
import com.tempmail.clone.data.remote.model.VerifyOtsWrapper
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Free-tier REST API (base `https://mob2.temp-mail.org`).
 * Recovered from `ApiClient.RestApiClient` (free methods b/d/k/n/p/v).
 */
interface FreeApi {
    /** Create / re-issue a free mailbox for the stored token. */
    @POST("/mailbox")
    suspend fun createMailbox(
        @Header("Authorization") auth: String?,
    ): Response<GetMailboxWrapper>

    /** Validate an existing free mailbox token. */
    @GET("/mailbox")
    suspend fun verifyMailbox(
        @Header("Authorization") auth: String?,
    ): Response<VerifyMailboxWrapper>

    /** List free messages newer than [after] (seconds). */
    @GET("/messages")
    suspend fun getMessages(
        @Header("Authorization") auth: String?,
        @Query("after") after: String?,
    ): Response<GetMessagesWrapper>

    /** Full body (html) of a single free message. */
    @GET("/messages/{emailId}/")
    suspend fun getMail(
        @Header("Authorization") auth: String?,
        @Path("emailId") emailId: String,
    ): Response<MailFree>

    /** Raw .eml source of a message. */
    @Headers("Accept: application/octet-stream")
    @GET("/messages/{emailId}/source")
    suspend fun getMailSource(
        @Header("Authorization") auth: String?,
        @Path("emailId") emailId: String,
    ): Response<ResponseBody>

    /** Raw attachment bytes. */
    @Headers("Accept: application/octet-stream")
    @GET("/messages/{emailId}/attachment/{attachmentId}/")
    suspend fun getAttachment(
        @Header("Authorization") auth: String?,
        @Path("emailId") emailId: String,
        @Path("attachmentId") attachmentId: Int,
    ): Response<ResponseBody>
}

/**
 * Premium JSON-RPC API (base `https://papi2.temp-mail.org`).
 * Every call is a single `POST /rpc/` with a method-specific body.
 */
interface PremiumApi {
    @POST("/rpc/")
    suspend fun getDomains(@Body body: DomainsBody): Response<DomainsWrapper>

    @POST("/rpc/")
    suspend fun addPrivateDomain(@Body body: AddDomainBody): Response<AddPrivateDomainWrapper>

    @POST("/rpc/")
    suspend fun getPrivateDomains(@Body body: GetPrivateDomainBody): Response<GetPrivateDomainsWrapper>

    @POST("/rpc/")
    suspend fun deletePrivateDomain(@Body body: DeletePrivateDomainBody): Response<EmptyResultWrapper>

    @POST("/rpc/")
    suspend fun listMailboxes(@Body body: MailboxesBody): Response<InboxListWrapper>

    @POST("/rpc/")
    suspend fun getMailboxMessages(@Body body: SingleMailboxBody): Response<PremiumEmailsWrapper>

    @POST("/rpc/")
    suspend fun createMailbox(@Body body: NewMailboxBody): Response<NewMailboxWrapper>

    @POST("/rpc/")
    suspend fun deleteMailbox(@Body body: DeleteEmailBody): Response<SidWrapper>

    @POST("/rpc/")
    suspend fun getMail(@Body body: GetMailBody): Response<GetMailWrapper>

    @POST("/rpc/")
    suspend fun getMailSource(@Body body: GetMailSourceBody): Response<GetMailSourceWrapper>

    @POST("/rpc/")
    suspend fun getAttachment(@Body body: GetAttachmentBody): Response<GetAttachmentWrapper>

    @POST("/rpc/")
    suspend fun updateFirebaseToken(@Body body: FirebaseTokenBody): Response<EmptyResultWrapper>

    @POST("/rpc/")
    suspend fun pushUpdate(@Body body: PushUpdateBody): Response<SidWrapper>

    @POST("/rpc/")
    suspend fun verifyOts(@Body body: VerifyOtsBody): Response<VerifyOtsWrapper>
}
