package com.tempmail.clone.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.tempmail.clone.util.Constants

@Database(
    entities = [EmailEntity::class, MailboxEntity::class, DomainEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun emailDao(): EmailDao
    abstract fun mailboxDao(): MailboxDao
    abstract fun domainDao(): DomainDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    Constants.DB_NAME,
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
    }
}
