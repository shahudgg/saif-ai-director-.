package com.tempmail.clone.ui.screens

import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Attachment
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tempmail.clone.ui.AppViewModel
import com.tempmail.clone.ui.anim.MotionTiming
import com.tempmail.clone.ui.components.CircleIconButton
import com.tempmail.clone.ui.components.HtmlContent
import com.tempmail.clone.ui.components.InitialsAvatar
import com.tempmail.clone.ui.theme.AppColors
import com.tempmail.clone.ui.theme.AppDimens
import com.tempmail.clone.util.Exporter
import com.tempmail.clone.util.Resource
import com.tempmail.clone.util.formatRelativeTime
import com.tempmail.clone.util.fromEmail
import com.tempmail.clone.util.fromName
import com.tempmail.clone.util.userInitials
import kotlinx.coroutines.launch

/**
 * Mail detail — mirrors `fragment_mail.xml` + `dialog_mail_dots_menu.xml`:
 * subject above a white rounded card (44dp initials avatar, sender, "to me",
 * time), the HTML body and a dots menu with print / save .eml / show original.
 */
@Composable
fun MailScreen(
    viewModel: AppViewModel,
    emailId: String,
    onBack: () -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val email = state.emails.firstOrNull { it.eid == emailId }
    var html by remember { mutableStateOf<String?>(null) }
    var source by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var menuOpen by remember { mutableStateOf(false) }

    // Body fades in once loaded (mirrors the original's `fade_in` on the mail
    // body replacement); when animations are off it snaps straight to 1.
    val bodyAlpha = remember { Animatable(if (state.animations) 0f else 1f) }
    LaunchedEffect(loading, source) {
        if (!loading) {
            if (state.animations) {
                bodyAlpha.snapTo(0f)
                bodyAlpha.animateTo(1f, tween(MotionTiming.LIST_FADE_MS, easing = MotionTiming.EaseOutCubic))
            } else {
                bodyAlpha.snapTo(1f)
            }
        }
    }

    LaunchedEffect(emailId) {
        if (email != null) {
            when (val result = viewModel.loadMailBody(email)) {
                is Resource.Success -> {
                    html = result.data
                    loading = false
                }
                is Resource.Error -> {
                    html = "<p>Could not load message: ${result.error.message}</p>"
                    loading = false
                }
                Resource.Loading -> Unit
            }
        } else {
            loading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = AppDimens.ToolbarTopMargin)
                .height(AppDimens.ToolbarHeight)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CircleIconButton(Icons.Filled.ArrowBack, onBack, "Back")
            Text(
                text = "Inbox",
                style = MaterialTheme.typography.headlineSmall,
                maxLines = 1,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
            )
            Box {
                CircleIconButton(
                    icon = Icons.Filled.MoreVert,
                    onClick = { menuOpen = true },
                    contentDescription = "More",
                )
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Print mail") },
                        onClick = {
                            menuOpen = false
                            html?.let { printHtml(context, it) }
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Download (.eml)") },
                        onClick = {
                            menuOpen = false
                            if (email != null) {
                                scope.launch {
                                    when (val r = viewModel.loadMailSource(email)) {
                                        is Resource.Success -> {
                                            val ok = Exporter.saveEml(context, email.subject.orEmpty(), r.data)
                                            android.widget.Toast.makeText(
                                                context,
                                                if (ok) "Saved to Download/TempMail" else "Could not save",
                                                android.widget.Toast.LENGTH_SHORT,
                                            ).show()
                                        }
                                        is Resource.Error -> Unit
                                        Resource.Loading -> Unit
                                    }
                                }
                            }
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Show Original") },
                        onClick = {
                            menuOpen = false
                            if (email != null) {
                                scope.launch {
                                    when (val r = viewModel.loadMailSource(email)) {
                                        is Resource.Success -> source = r.data
                                        is Resource.Error -> source = "Source unavailable: ${r.error.message}"
                                        Resource.Loading -> Unit
                                    }
                                }
                            }
                        },
                    )
                }
            }
        }

        if (email == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Message not found")
            }
            return@Column
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .graphicsLayer { alpha = bodyAlpha.value }
                .verticalScroll(rememberScrollState()),
        ) {
            Text(
                text = email.subject.orEmpty().ifBlank { "(no subject)" },
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 2,
                modifier = Modifier.padding(horizontal = 23.dp, vertical = 20.dp),
            )

            Column(
                modifier = Modifier
                    .padding(horizontal = AppDimens.MailHorizontalMargin)
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(AppDimens.CardRadius)),
            ) {
                Row(
                    modifier = Modifier.padding(AppDimens.MailHorizontalMargin + 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    InitialsAvatar(userInitials(fromName(email.fromField)))
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 10.dp),
                    ) {
                        Text(
                            text = fromName(email.fromField).ifBlank { "Unknown" },
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "to me",
                            style = MaterialTheme.typography.bodyLarge,
                            color = AppColors.GrayMain,
                        )
                    }
                    Text(
                        text = formatRelativeTime(email.timestampMs),
                        style = MaterialTheme.typography.labelMedium,
                        color = AppColors.GrayMain,
                    )
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp, modifier = Modifier.padding(top = 12.dp))

                if (loading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                } else if (source != null) {
                    Text(
                        text = source.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                    )
                } else {
                    HtmlContent(html = html.orEmpty(), modifier = Modifier.fillMaxWidth().height(460.dp))
                }
            }

            if (email.attachmentsCount > 0) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Attachment, contentDescription = null, tint = AppColors.GrayMain, modifier = Modifier.size(16.dp))
                    Text(
                        text = "${email.attachmentsCount} attachment(s)",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(start = 6.dp),
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // Sender email footer line (mirrors the small "from" detail in the card).
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = AppDimens.MailHorizontalMargin, vertical = 6.dp),
            contentAlignment = Alignment.Center,
        ) {
            if (fromEmail(email.fromField).isNotBlank()) {
                Text(
                    text = fromEmail(email.fromField),
                    style = MaterialTheme.typography.labelSmall,
                    color = AppColors.GrayMain,
                    modifier = Modifier.clickable { copyToClipboard(context, fromEmail(email.fromField)) },
                )
            }
        }
    }
}

private fun printHtml(context: android.content.Context, html: String) {
    val webView = WebView(context).apply {
        loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }
    val printManager = context.getSystemService(android.content.Context.PRINT_SERVICE) as PrintManager
    printManager.print("Temp Mail", webView.createPrintDocumentAdapter(), PrintAttributes.Builder().build())
}
