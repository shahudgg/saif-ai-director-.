package com.tempmail.clone.ui.anim

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * Timing / easing tokens recovered from the original decompiled sources:
 *
 *  - `res/anim/fade_in.xml` / `fade_out.xml`             → 250ms alpha
 *  - `res/values/integers.xml config_navAnimTime`        → 150ms nav fade
 *  - `MailboxFragmentPresenter.animateCopyButton`        → 200ms scale 1.0 → 0.9
 *  - `MailboxFragmentPresenter.restoreBtnStateAfterDelay`→ 1500ms delay + 200ms scale back
 *  - `MailboxFragmentPresenter.scaleDownAndUpAnimation`  → 0ms to 0.9, then 250ms to 1.0
 *  - `CustomSwipeRefreshLayout`                          → 300ms translate + 1500ms minimum refine
 *  - `InboxFragment` spinner hide                        → 300ms translationY + alpha
 *  - the fire delete flow                                → reveal at 75% of the animation
 *  - `res/anim/pulse_animation.xml`                      → 500ms scale 1.0 → 1.2, ×2 reverse
 *  - `res/anim/shape_animation.xml`                      → 50ms ±5% / ±2% shake, ×4 reverse
 *
 * The clone ships no Lottie runtime (the original `.json` assets are not
 * redistributed), so every "Lottie" moment is rebuilt with native Compose
 * animation primitives that keep the exact same durations and triggers.
 */
object MotionTiming {
    /** `res/anim/fade_in.xml` — cross-fade between navigation destinations. */
    const val NAV_FADE_MS = 250

    /** `@integer/config_navAnimTime` — the graph's global fade action. */
    const val GLOBAL_NAV_MS = 150

    /** Press scale-down of the copy button. */
    const val COPY_PRESS_MS = 200

    /** The copy button reverts to "Copy email" after this delay. */
    const val COPY_RESTORE_DELAY_MS = 1500L

    /** Label / icon revert scale-up. */
    const val COPY_RESTORE_MS = 200

    /** `scaleDownAndUpAnimation`: bounce back up. */
    const val BOUNCE_MS = 250

    /** `pulse_animation.xml`: 500ms per leg. */
    const val PULSE_MS = 500
    const val PULSE_REPEATS = 2

    /** `shape_animation.xml`: 50ms per leg. */
    const val SHAKE_MS = 50
    const val SHAKE_REPEATS = 4

    /** `CustomSwipeRefreshLayout` translate duration. */
    const val REFRESH_TRANSLATE_MS = 300

    /** Minimum time the owl keeps spinning. */
    const val REFRESH_MIN_MS = 1500L

    /** `InboxFragment` spinner fade (`animate().translationY(0).alpha(1)`). */
    const val SPINNER_MS = 300

    /** Trigger fraction of the fire animation before the mailbox changes. */
    const val FIRE_REVEAL_FRACTION = 0.75f

    /** Duration the "new message" pill takes to fade in. */
    const val NEW_MESSAGE_MS = 300

    /** RecyclerView-style fade for inserted rows. */
    const val LIST_FADE_MS = 220

    /** Stagger between consecutive list / menu rows. */
    const val STAGGER_MS = 45

    /** Splash hold time (`activity_splash.xml` scale-up + delay). */
    const val SPLASH_MS = 900L

    /** Splash logo scale-up on launch. */
    const val SPLASH_LOGO_MS = 400

    val EaseOutCubic: CubicBezierEasing = CubicBezierEasing(0f, 0f, 0.2f, 1f)
    val EaseInOutCubic: CubicBezierEasing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)
    val EaseStandard: CubicBezierEasing = CubicBezierEasing(0.2f, 0f, 0f, 1f)
}

/**
 * Screen-level entrance fade identical to `@anim/fade_in` (250ms alpha 0→1).
 * Used around every navigation destination instead of Material's shared-axis
 * transition, matching the original `fragment_fade_enter` behaviour.
 */
@Composable
fun ScreenFade(
    modifier: Modifier = Modifier,
    durationMs: Int = MotionTiming.NAV_FADE_MS,
    content: @Composable () -> Unit,
) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMs, easing = LinearEasing),
        label = "screenFade",
    )
    Box(modifier = modifier.fillMaxSize().alpha(alpha)) { content() }
}

/**
 * Per-row entry animation for lists and drawers. Mirrors the way the original
 * RecyclerView population and the `nav_default_*_anim` fades made rows appear
 * one after another.
 */
@Composable
fun StaggeredItem(
    key: Any?,
    modifier: Modifier = Modifier,
    index: Int = 0,
    content: @Composable () -> Unit,
) {
    var visible by remember(key) { mutableStateOf(false) }
    LaunchedEffect(key) {
        visible = false
        delay((index.coerceAtMost(12) * MotionTiming.STAGGER_MS).toLong())
        visible = true
    }
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(MotionTiming.LIST_FADE_MS, easing = EaseInOut),
        label = "staggerAlpha",
    )
    val translation by animateFloatAsState(
        targetValue = if (visible) 0f else 18f,
        animationSpec = tween(MotionTiming.LIST_FADE_MS, easing = MotionTiming.EaseOutCubic),
        label = "staggerY",
    )
    Box(
        modifier = modifier.graphicsLayer {
            this.alpha = alpha
            translationY = translation
        },
    ) {
        content()
    }
}

/**
 * `res/anim/pulse_animation.xml` — 1.0 → 1.2 → 1.0, twice, 500ms each way.
 * Wraps an element (unread badge, premium pill) and pulses it when [trigger]
 * changes.
 */
@Composable
fun PulseAnimation(
    trigger: Any?,
    modifier: Modifier = Modifier,
    maxScale: Float = 1.2f,
    content: @Composable () -> Unit,
) {
    val anim = remember { Animatable(1f) }
    LaunchedEffect(trigger) {
        repeat(MotionTiming.PULSE_REPEATS) {
            anim.animateTo(maxScale, tween(MotionTiming.PULSE_MS, easing = EaseInOut))
            anim.animateTo(1f, tween(MotionTiming.PULSE_MS, easing = EaseInOut))
        }
        anim.snapTo(1f)
    }
    Box(modifier = modifier.scale(anim.value)) { content() }
}

/**
 * `res/anim/shape_animation.xml` — a very fast (±5% x, ±2% y) shake, 4 times.
 * The original only fired this on the "Copied" confirmation text.
 */
@Composable
fun ShakeAnimation(
    playing: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(playing) {
        if (playing) {
            repeat(MotionTiming.SHAKE_REPEATS) {
                anim.animateTo(1f, tween(MotionTiming.SHAKE_MS, easing = LinearEasing))
                anim.animateTo(-1f, tween(MotionTiming.SHAKE_MS, easing = LinearEasing))
            }
            anim.animateTo(0f, tween(MotionTiming.SHAKE_MS, easing = LinearEasing))
        }
    }
    Box(
        modifier = modifier.graphicsLayer {
            translationX = anim.value * 5f
            translationY = anim.value * 2f
        },
    ) {
        content()
    }
}

/**
 * The "new message" pill from `fragment_email_address.xml` (`tvNewMessage`,
 * `alpha 0.0` → animated to 1.0 over 300ms).
 */
@Composable
fun NewMessagePill(
    visible: Boolean,
    text: String,
    modifier: Modifier = Modifier,
) {
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(MotionTiming.NEW_MESSAGE_MS, easing = MotionTiming.EaseOutCubic),
        label = "newMessage",
    )
    if (alpha <= 0.01f) return
    Box(
        modifier = modifier
            .alpha(alpha)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.primary)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
        )
    }
}
