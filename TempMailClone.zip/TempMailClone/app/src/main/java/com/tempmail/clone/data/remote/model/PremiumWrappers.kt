package com.tempmail.clone.data.remote.model

import com.google.gson.annotations.SerializedName

// ---------------------------------------------------------------------------
// Request bodies (com.tempmail.data.api.models.requests.*)
// Each carries a JSON-RPC method name and a typed `params` object.
// ---------------------------------------------------------------------------

class DomainsBody(sid: String?) : RpcBody("getdomains") {
    var params: Params = Params(sid)
    data class Params(var sid: String?)
}

class AddDomainBody(sid: String?, domain: String?) : RpcBody("domain.add") {
    var params: Params = Params(sid, domain)
    data class Params(var sid: String?, var domain: String?)
}

class GetPrivateDomainBody(sid: String?) : RpcBody("domain.get") {
    var params: Params = Params(sid)
    data class Params(var sid: String?)
}

class DeletePrivateDomainBody(sid: String?, domain: String?) : RpcBody("domain.delete") {
    var params: Params = Params(sid, domain)
    data class Params(var sid: String?, var domain: String?)
}

class MailboxesBody(sid: String?, lastCheck: String?) : RpcBody("mailbox.listv2") {
    var params: Params = Params(sid, lastCheck)
    data class Params(var sid: String?, var lastCheck: String?)
}

class SingleMailboxBody(sid: String?, lastCheck: String?, email: String?) : RpcBody("mailbox.messages") {
    var params: Params = Params(sid, lastCheck, email)
    data class Params(var sid: String?, var lastCheck: String?, var email: String?)
}

class NewMailboxBody(sid: String?, email: String?, domain: String?) : RpcBody("mailbox.new") {
    var params: Params = Params(sid, email, domain)
    data class Params(var sid: String?, var email: String?, var domain: String?)
}

class DeleteEmailBody(sid: String?, email: String?) : RpcBody("mailbox.delete") {
    var params: Params = Params(sid, email)
    data class Params(var sid: String?, var email: String?)
}

class GetMailBody(sid: String?, mailId: String?) : RpcBody("mail.get") {
    var params: Params = Params(sid, mailId)
    data class Params(var sid: String?, @SerializedName("mail") var mailId: String?)
}

class GetMailSourceBody(sid: String?, mailId: String?) : RpcBody("mail.source") {
    var params: Params = Params(sid, mailId, true)
    data class Params(
        var sid: String?,
        @SerializedName("mail") var mailId: String?,
        @SerializedName("base64") var isBase64Response: Boolean,
    )
}

class GetAttachmentBody(sid: String?, attachmentName: String?, mailId: String?, attachmentId: Int) :
    RpcBody("mail.attachment") {
    var params: Params = Params(sid, attachmentName, mailId, attachmentId)
    data class Params(
        var sid: String?,
        var attachmentName: String?,
        @SerializedName("mail") var mailId: String?,
        @SerializedName("_id") var attachmentId: Int,
    )
}

class VerifyOtsBody(sid: String?, ots: String?) : RpcBody("user.verify_ots") {
    var params: Params = Params(sid, ots)
    data class Params(var sid: String?, var ots: String?)
}

class FirebaseTokenBody(sid: String?, firebaseToken: String?, pushEnabled: Boolean) :
    RpcBody("firebase.token") {
    var params: Params = Params(sid, firebaseToken, pushEnabled)
    data class Params(var sid: String?, var firebaseToken: String?, var pushEnabled: Boolean)
}

class PushUpdateBody(sid: String?, pushEnabled: Boolean) : RpcBody("push.update") {
    var params: Params = Params(sid, pushEnabled)
    data class Params(var sid: String?, var pushEnabled: Boolean)
}

// ---------------------------------------------------------------------------
// Answer wrappers (com.tempmail.data.api.models.answers.*)
// ---------------------------------------------------------------------------

class DomainsWrapper : RpcWrapper() {
    @SerializedName("result") var result: ResultDomains? = null
}

class ResultDomains {
    @SerializedName("domains_exp") var domainsExp: List<DomainExpire>? = null
}

/** mailbox.listv2 */
class InboxListWrapper : RpcWrapper() {
    @SerializedName("result") var result: InboxListResult? = null

    class InboxListResult {
        @SerializedName("mails") var mailAddresses: Map<String, List<PremiumMailInbox>>? = null
        var sid: String? = null
    }
}

/** mailbox.messages */
class PremiumEmailsWrapper : RpcWrapper() {
    @SerializedName("result") var result: ResultEmails? = null
}

class ResultEmails {
    @SerializedName("mails") var mailList: List<ExtendedMail>? = null
    var mailbox: String? = null
    var sid: String? = null
}

/** mail.get */
class GetMailWrapper : RpcWrapper() {
    @SerializedName("result") var result: ResultGetMail? = null
}

class ResultGetMail {
    var message: SinglePremiumMail? = null
    var sid: String? = null
}

/** mail.source */
class GetMailSourceWrapper : RpcWrapper() {
    @SerializedName("result") var result: ResultMailSource? = null
}

class ResultMailSource {
    var message: Message? = null
    var sid: String? = null

    class Message {
        @SerializedName("mail_address") var mailAddress: String? = null
        @SerializedName("mail_address_id") var mailAddressId: String? = null
        @SerializedName("mail_id") var mailId: String? = null
        @SerializedName("mail_source") var mailSource: String? = null
        @SerializedName("mail_timestamp") var mailTimestamp: String? = null
    }
}

/** mail.attachment */
class GetAttachmentWrapper : RpcWrapper() {
    @SerializedName("result") var result: ResultAttachments? = null
}

class ResultAttachments {
    var attachment: Attachment? = null
    var sid: String? = null

    class Attachment {
        var cid: String? = null
        var contentType: String? = null
        var data: String? = null
        var filename: String? = null
        var size: String? = null
    }
}

/** mailbox.new */
class NewMailboxWrapper : RpcWrapper() {
    @SerializedName("result") var result: Result? = null

    class Result {
        var domain: String? = null
        var email: String? = null
        var sid: String? = null
    }
}

/** domain.get */
class GetPrivateDomainsWrapper : RpcWrapper() {
    @SerializedName("result") var result: ResultGetDomains? = null

    class ResultGetDomains {
        var domains: List<PrivateDomain>? = null
    }
}

class PrivateDomain {
    var domain: String? = null
    var mailboxesCount: Int = 0
    var mailsCount: Int = 0
    var status: String? = null
    var type: String? = null
}

/** domain.add */
class AddPrivateDomainWrapper : RpcWrapper() {
    @SerializedName("result") var result: ResultAddDomain? = null

    class ResultAddDomain {
        var domain: String? = null
        var status: String? = null
    }
}

/** mailbox.delete / subscription.update */
class SidWrapper : RpcWrapper() {
    @SerializedName("result") var result: Result? = null
    class Result { var sid: String? = null }
}

/** firebase.token */
class EmptyResultWrapper : RpcWrapper() {
    @SerializedName("result") var result: Result? = null
    class Result
}

/** user.verify_ots — verifies a one-time-signature from a QR/deeplink. */
class VerifyOtsWrapper : RpcWrapper() {
    @SerializedName("result") var result: Result? = null
    class Result { var sid: String? = null }
}

/** Premium inbox mail (mailbox.listv2). */
open class BaseMailPremium {
    @SerializedName("mail_from") var mailFrom: String? = null
    @SerializedName("mail_html") var mailHtml: String? = null
    @SerializedName("mail_id") var mailId: String? = null
    @SerializedName("mail_subject") var mailSubject: String? = null
    @SerializedName("mail_text") var mailText: String? = null
    @SerializedName("mail_text_only") var mailTextOnly: String? = null
    @SerializedName("mail_timestamp") var mailTimestamp: Double = 0.0
    @SerializedName("mail_preview") var preview: String? = null
}

class PremiumMailInbox : BaseMailPremium() {
    @SerializedName("mail_attachments") var attachmentsCount: Int = 0
}

class SinglePremiumMail : BaseMailPremium() {
    @SerializedName("mail_attachments") var attachmentInfo: List<ExtendedMail.AttachmentInfo>? = null
}
