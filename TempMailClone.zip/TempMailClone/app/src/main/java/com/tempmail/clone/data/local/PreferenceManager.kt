package com.tempmail.clone.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "temp_mail")

/**
 * DataStore-backed settings. Preference keys match the original
 * `SharedPreferenceHelper` where they overlap ("free_jwt" = free token,
 * "sid" = premium session, "language", "is_dark_mode_enabled", ...).
 */
class PreferenceManager(private val context: Context) {

    private object Keys {
        val FREE_TOKEN = stringPreferencesKey("free_jwt")
        val SID = stringPreferencesKey("sid")
        val LAST_CHECK = stringPreferencesKey("last_check_ms")
        val LAST_DOMAIN_CHOSEN = stringPreferencesKey("last_domain_chosen")
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val DARK_MODE = booleanPreferencesKey("is_dark_mode_enabled")
        val ANIMATIONS = booleanPreferencesKey("is_show_animations")
        val NOTIFICATIONS = booleanPreferencesKey("is_show_push_notifications")
        val AUTOFILL = booleanPreferencesKey("is_autofill_enabled")
        val LANGUAGE = stringPreferencesKey("language")
        val PREMIUM = booleanPreferencesKey("is_premium")
    }

    val freeToken: Flow<String?> = context.dataStore.data.map { it[Keys.FREE_TOKEN] }
    val sid: Flow<String?> = context.dataStore.data.map { it[Keys.SID] }
    val lastCheck: Flow<String?> = context.dataStore.data.map { it[Keys.LAST_CHECK] }
    val lastDomainChosen: Flow<String?> = context.dataStore.data.map { it[Keys.LAST_DOMAIN_CHOSEN] }
    val onboarded: Flow<Boolean> = context.dataStore.data.map { it[Keys.ONBOARDED] ?: false }
    val darkMode: Flow<Boolean?> = context.dataStore.data.map { it[Keys.DARK_MODE] }
    val animations: Flow<Boolean?> = context.dataStore.data.map { it[Keys.ANIMATIONS] }
    val notifications: Flow<Boolean> = context.dataStore.data.map { it[Keys.NOTIFICATIONS] ?: true }
    val autofill: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTOFILL] ?: false }
    val language: Flow<String?> = context.dataStore.data.map { it[Keys.LANGUAGE] }
    val isPremium: Flow<Boolean> = context.dataStore.data.map { it[Keys.PREMIUM] ?: false }

    /** Last known free mailbox token ("free_jwt"). */
    suspend fun currentFreeToken(): String? = freeToken.first()

    suspend fun setFreeToken(token: String?) = context.dataStore.edit { it[Keys.FREE_TOKEN] = token.orEmpty() }
    suspend fun setSid(sid: String?) = context.dataStore.edit { if (sid == null) it.remove(Keys.SID) else it[Keys.SID] = sid }
    suspend fun setLastCheck(ms: Long) = context.dataStore.edit { it[Keys.LAST_CHECK] = ms.toString() }
    suspend fun setLastDomainChosen(domain: String?) = context.dataStore.edit { it[Keys.LAST_DOMAIN_CHOSEN] = domain.orEmpty() }
    suspend fun setOnboarded(value: Boolean) = context.dataStore.edit { it[Keys.ONBOARDED] = value }
    suspend fun setDarkMode(value: Boolean) = context.dataStore.edit { it[Keys.DARK_MODE] = value }
    suspend fun setAnimations(value: Boolean) = context.dataStore.edit { it[Keys.ANIMATIONS] = value }
    suspend fun setNotifications(value: Boolean) = context.dataStore.edit { it[Keys.NOTIFICATIONS] = value }
    suspend fun setAutofill(value: Boolean) = context.dataStore.edit { it[Keys.AUTOFILL] = value }
    suspend fun setLanguage(value: String?) = context.dataStore.edit { it[Keys.LANGUAGE] = value.orEmpty() }
    suspend fun setPremium(value: Boolean) = context.dataStore.edit { it[Keys.PREMIUM] = value }
}
