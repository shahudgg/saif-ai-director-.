package com.tempmail.clone

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tempmail.clone.ui.AppRoot
import com.tempmail.clone.ui.theme.TempMailTheme

/**
 * Single-activity host. The original used MainActivity + a NavHostFragment
 * graph (`nav_mailbox` → `nav_inbox` → `nav_mail` → `nav_switch_email`);
 * the clone reproduces that graph with Compose Navigation (see AppRoot).
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val app = application as App
            val viewModel = com.tempmail.clone.ui.sharedViewModel(app)
            val state by viewModel.state.collectAsStateWithLifecycle()
            TempMailTheme(darkOverride = state.darkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot()
                }
            }
        }
    }
}
