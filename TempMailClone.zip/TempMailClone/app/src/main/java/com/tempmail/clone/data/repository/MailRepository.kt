package com.tempmail.clone.data.repository

import com.tempmail.clone.data.local.EmailDao
import com.tempmail.clone.data.local.EmailEntity
import com.tempmail.clone.data.local.PreferenceManager
import com.tempmail.clone.data.remote.FreeApi
import com.tempmail.clone.data.remote.PremiumApi
import com.tempmail.clone.data.remote.model.GetAttachmentBody
import com.tempmail.clone.data.remote.model.GetMailBody
import com.tempmail.clone.data.remote.model.GetMailSourceBody
import com.tempmail.clone.util.ApiError
import com.tempmail.clone.util.Resource
import kotlinx.coroutines.flow.first

/**
 * Single-message body + source + attachments.
 * Ported from `com.tempmail.data.repository.MailRepository` / AttachmentsRepository.
 */
class MailRepository(
    private val freeApi: FreeApi,
    private val premiumApi: PremiumApi,
    private val emailDao: EmailDao,
    private val prefs: PreferenceManager,
) {

    /** Full HTML body of a message. Caches `isDetailsLoaded` locally. */
    suspend fun loadBody(email: EmailEntity, isPremium: Boolean): Resource<String> {
        return try {
            if (isPremium) {
                val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
                val response = premiumApi.getMail(GetMailBody(sid, email.eid))
                val wrapper = response.body()
                val error = wrapper?.error
                val message = wrapper?.result?.message
                if (!response.isSuccessful || error != null || message == null) {
                    Resource.Error(ApiError(error?.code ?: response.code(), error?.message, error?.errorName, error?.subCode))
                } else {
                    emailDao.markDetailsLoaded(email.eid)
                    Resource.Success(message.mailHtml ?: message.mailTextOnly ?: message.mailText ?: "")
                }
            } else {
                val token = prefs.currentFreeToken() ?: return Resource.Error(ApiError(401, "No token"))
                val response = freeApi.getMail("Bearer $token", email.eid)
                val body = response.body()
                if (!response.isSuccessful || body == null) {
                    Resource.Error(ApiError(response.code(), "Message unavailable"))
                } else {
                    emailDao.markDetailsLoaded(email.eid)
                    Resource.Success(body.mailHtml)
                }
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    /** Raw .eml source (used for "Show original" / "Save .eml"). */
    suspend fun loadSource(email: EmailEntity, isPremium: Boolean): Resource<String> {
        return try {
            if (isPremium) {
                val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
                val response = premiumApi.getMailSource(GetMailSourceBody(sid, email.eid))
                val wrapper = response.body()
                val error = wrapper?.error
                val source = wrapper?.result?.message?.mailSource
                if (!response.isSuccessful || error != null || source == null) {
                    Resource.Error(ApiError(error?.code ?: response.code(), error?.message))
                } else {
                    Resource.Success(source)
                }
            } else {
                val token = prefs.currentFreeToken() ?: return Resource.Error(ApiError(401, "No token"))
                val response = freeApi.getMailSource("Bearer $token", email.eid)
                val body = response.body()
                if (!response.isSuccessful || body == null) {
                    Resource.Error(ApiError(response.code(), "Source unavailable"))
                } else {
                    Resource.Success(body.string())
                }
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    /** Download one attachment's raw bytes (free) — premium returns base64 via RPC. */
    suspend fun loadAttachmentBytes(
        email: EmailEntity,
        attachmentId: Int,
        attachmentName: String?,
        isPremium: Boolean,
    ): Resource<ByteArray> {
        return try {
            if (isPremium) {
                val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
                val body = GetAttachmentBody(sid, attachmentName, email.eid, attachmentId)
                val response = premiumApi.getAttachment(body)
                val wrapper = response.body()
                val error = wrapper?.error
                val data = wrapper?.result?.attachment?.data
                if (!response.isSuccessful || error != null || data == null) {
                    Resource.Error(ApiError(error?.code ?: response.code(), error?.message))
                } else {
                    Resource.Success(android.util.Base64.decode(data, android.util.Base64.DEFAULT))
                }
            } else {
                val token = prefs.currentFreeToken() ?: return Resource.Error(ApiError(401, "No token"))
                val response = freeApi.getAttachment("Bearer $token", email.eid, attachmentId)
                val body = response.body()
                if (!response.isSuccessful || body == null) {
                    Resource.Error(ApiError(response.code(), "Attachment unavailable"))
                } else {
                    Resource.Success(body.bytes())
                }
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }
}
