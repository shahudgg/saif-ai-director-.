package com.tempmail.clone.ui.anim

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.abs

/** Total run time of the fire sweep (the original `@raw/fire` Lottie, 180 frames @ 60fps ≈ 3s but eased to fit a swap). */
private const val FIRE_MS = 1200

/**
 * Full-screen "fire" wipe used when the temporary address is replaced
 * (`MailboxFragmentPresenter.playFireAnimation` → `scaleDownAndUpAnimation`).
 *
 * In the original a `@raw/fire` Lottie (`activity_main.xml#animationFire`) is made
 * visible, played, and when it reaches **75%** of its track the mailbox / envelope
 * swap happens ([onReveal]). The clone ships no Lottie runtime, so the flames are
 * rebuilt with native vector drawing while keeping the same trigger contract.
 */
@Composable
fun FireOverlay(
    visible: Boolean,
    modifier: Modifier = Modifier,
    durationMs: Int = FIRE_MS,
    onReveal: (() -> Unit)? = null,
    onFinished: (() -> Unit)? = null,
) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(visible) {
        if (!visible) {
            progress.snapTo(0f)
            return@LaunchedEffect
        }
        var revealed = false
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMs, easing = LinearEasing),
        ) {
            if (!revealed && value >= MotionTiming.FIRE_REVEAL_FRACTION) {
                revealed = true
                onReveal?.invoke()
            }
        }
        onFinished?.invoke()
    }

    val p = progress.value
    if (p <= 0f) return
    Canvas(modifier = modifier.fillMaxSize()) { drawFire(p) }
}

/**
 * A rising bed of fire tongues plus a bottom-up heat glow, driven by [p] (0..1).
 * Kept deliberately thin so it reads as a fast wipe rather than a decorative loop.
 */
private fun DrawScope.drawFire(p: Float) {
    val w = size.width
    val h = size.height

    // Heat glow is strongest mid-sweep.
    val glow = (1f - abs(p - 0.5f) * 2f).coerceIn(0f, 1f)
    drawRect(
        brush = Brush.verticalGradient(
            0f to Color.Transparent,
            0.35f to Color(0xFFFF3D00).copy(alpha = 0.30f * glow),
            0.70f to Color(0xFFFF7A00).copy(alpha = 0.42f * glow),
            1f to Color(0xFFFFD54A).copy(alpha = 0.50f * glow),
        ),
    )

    // Flame tongues sweep upward and retreat a little toward the end.
    val count = 7
    val baseY = h * 1.06f - h * 0.16f * p
    for (i in 0 until count) {
        val t = (i + 1f) / (count + 1f)
        val cx = w * t
        val bw = w * (0.11f + 0.025f * (i % 3))
        val fh = h * (0.30f + 0.50f * p) * (1f - 0.12f * (i % 2))
        flamePath(cx, baseY, bw, fh).let { flame ->
            drawPath(
                path = flame,
                brush = Brush.verticalGradient(
                    0f to Color(0xFFFF3D00).copy(alpha = 0.40f),
                    0.45f to Color(0xFFFF7A00).copy(alpha = 0.55f),
                    1f to Color(0xFFFFC107).copy(alpha = 0.65f),
                    startY = baseY - fh,
                    endY = baseY,
                ),
            )
        }
    }
}

private fun flamePath(cx: Float, baseY: Float, bw: Float, fh: Float): Path = Path().apply {
    moveTo(cx - bw, baseY)
    cubicTo(
        cx - bw, baseY - fh * 0.45f,
        cx - bw * 0.35f, baseY - fh * 0.70f,
        cx, baseY - fh,
    )
    cubicTo(
        cx + bw * 0.35f, baseY - fh * 0.70f,
        cx + bw, baseY - fh * 0.45f,
        cx + bw, baseY,
    )
    close()
}

/**
 * Scale-"bounce" used by `MailboxFragmentPresenter.scaleDownAndUpAnimation`:
 * snap to 0.9 instantly, then ease back to 1.0 over 250ms. Returns the current
 * scale to feed into `Modifier.graphicsLayer`.
 */
@Composable
fun rememberBounceOnChange(key: Any?): Float {
    val scale = remember { Animatable(1f) }
    LaunchedEffect(key) {
        scale.snapTo(0.9f)
        scale.animateTo(1f, tween(MotionTiming.BOUNCE_MS, easing = MotionTiming.EaseOutCubic))
    }
    return scale.value
}

/** Unused-but-documented: the original also shipped a dead `@raw/shredder` view. */
@Suppress("unused")
internal val FireRevealFraction = MotionTiming.FIRE_REVEAL_FRACTION
