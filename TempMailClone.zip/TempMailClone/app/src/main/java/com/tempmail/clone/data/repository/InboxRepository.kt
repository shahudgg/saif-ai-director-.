package com.tempmail.clone.data.repository

import com.tempmail.clone.data.local.EmailDao
import com.tempmail.clone.data.local.EmailEntity
import com.tempmail.clone.data.local.MailboxDao
import com.tempmail.clone.data.local.PreferenceManager
import com.tempmail.clone.data.remote.FreeApi
import com.tempmail.clone.data.remote.PremiumApi
import com.tempmail.clone.data.remote.model.MailboxesBody
import com.tempmail.clone.data.remote.model.SingleMailboxBody
import com.tempmail.clone.util.ApiError
import com.tempmail.clone.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

/**
 * Inbox sync + local mail cache.
 * Ported from `com.tempmail.data.repository.InboxRepository`.
 *
 * Free  : GET /messages?after=<lastCheck>      (Authorization: Bearer <token>)
 * Premium: RPC mailbox.listv2 / mailbox.messages (sid)
 */
class InboxRepository(
    private val freeApi: FreeApi,
    private val premiumApi: PremiumApi,
    private val emailDao: EmailDao,
    private val prefs: PreferenceManager,
) {

    fun observeEmails(address: String): Flow<List<EmailEntity>> = emailDao.observeForMailbox(address)
    fun observeUnread(address: String): Flow<Int> = emailDao.observeUnreadCount(address)
    suspend fun unread(address: String): Int = emailDao.unreadCount(address)
    suspend fun byId(eid: String): EmailEntity? = emailDao.byId(eid)
    fun observeById(eid: String): Flow<EmailEntity?> = emailDao.observeById(eid)

    /**
     * Refresh the inbox for [address] from the backend and persist new rows.
     * Returns the number of messages reported by the server.
     */
    suspend fun refresh(address: String, isPremium: Boolean): Resource<Int> {
        return if (isPremium) refreshPremium(address) else refreshFree(address)
    }

    private suspend fun refreshFree(address: String): Resource<Int> {
        val token = prefs.currentFreeToken() ?: return Resource.Error(ApiError(401, "No token"))
        return try {
            val after = prefs.lastCheck.first()
            val response = freeApi.getMessages("Bearer $token", after)
            val body = response.body()
            if (!response.isSuccessful || body == null) {
                Resource.Error(ApiError(response.code(), body?.errorMessage ?: body?.errorName))
            } else {
                val messages = body.messages.orEmpty()
                val entities = messages.map { it.toEntity(address) }
                if (entities.isNotEmpty()) emailDao.upsertAll(entities)
                prefs.setLastCheck(System.currentTimeMillis())
                Resource.Success(body.messageCount ?: messages.size)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    private suspend fun refreshPremium(address: String): Resource<Int> {
        val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
        return try {
            val after = prefs.lastCheck.first()
            val response = premiumApi.getMailboxMessages(SingleMailboxBody(sid, after, address))
            val wrapper = response.body()
            val error = wrapper?.error
            val mails = wrapper?.result?.mailList
            if (!response.isSuccessful || error != null || mails == null) {
                Resource.Error(ApiError(error?.code ?: response.code(), error?.message, error?.errorName, error?.subCode))
            } else {
                val entities = mails.map { it.toEntity(address) }
                if (entities.isNotEmpty()) emailDao.upsertAll(entities)
                prefs.setLastCheck(System.currentTimeMillis())
                Resource.Success(entities.size)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    /** Premium: full mailbox list across all addresses (`mailbox.listv2`). */
    suspend fun refreshAllPremium(): Resource<Map<String, List<EmailEntity>>> {
        val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
        return try {
            val after = prefs.lastCheck.first()
            val response = premiumApi.listMailboxes(MailboxesBody(sid, after))
            val wrapper = response.body()
            val error = wrapper?.error
            val map = wrapper?.result?.mailAddresses
            if (!response.isSuccessful || error != null || map == null) {
                Resource.Error(ApiError(error?.code ?: response.code(), error?.message, error?.errorName, error?.subCode))
            } else {
                val result = LinkedHashMap<String, List<EmailEntity>>()
                map.forEach { (mailbox, mails) ->
                    val entities = mails.map { it.toEntity(mailbox) }
                    if (entities.isNotEmpty()) emailDao.upsertAll(entities)
                    result[mailbox] = entities
                }
                prefs.setLastCheck(System.currentTimeMillis())
                Resource.Success(result)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    suspend fun markDeleted(email: EmailEntity) = emailDao.markDeleted(email.eid)
    suspend fun setChecked(eid: String, checked: Boolean) = emailDao.setChecked(eid, checked)
    suspend fun toggleReadStatus(email: EmailEntity) = emailDao.setChecked(email.eid, !email.isChecked)
    suspend fun markDetailsLoaded(eid: String) = emailDao.markDetailsLoaded(eid)
    suspend fun clearMailbox(address: String) = emailDao.clearMailbox(address)
    suspend fun purge() = emailDao.purgeDeletedAndOld(System.currentTimeMillis() - 30L * 24 * 3600 * 1000)
}
