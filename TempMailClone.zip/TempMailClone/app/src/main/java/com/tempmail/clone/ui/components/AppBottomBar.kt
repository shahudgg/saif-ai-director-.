package com.tempmail.clone.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.tempmail.clone.ui.anim.MotionTiming
import com.tempmail.clone.ui.anim.PulseAnimation
import com.tempmail.clone.ui.theme.AppColors

enum class BottomTab(val label: String, val icon: ImageVector) {
    Email("Email", Icons.Filled.Email),
    Inbox("Inbox", Icons.Filled.Inbox),
    Manage("Manage", Icons.Filled.List),
}

/**
 * Bottom navigation reconstructed from `menu/bottom_navigation_menu.xml` +
 * `layout/bottom_navigation_item.xml`: 30dp icon over a 12sp label, the active
 * item drawn in the primary text colour, the rest in `gray_main`, and an
 * optional red unread badge on the Inbox tab.
 *
 * The badge reproduces `MainActivity.w4(TextView)`: it pulses
 * (`@anim/pulse_animation`, 500ms ×2 reverse) and fires a haptic tick whenever
 * the unread count changes; the tab tint cross-fades on selection.
 */
@Composable
fun AppBottomBar(
    selected: BottomTab,
    unreadCount: Int,
    onSelect: (BottomTab) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BottomTab.entries.forEach { tab ->
            BottomItem(
                tab = tab,
                selected = tab == selected,
                unread = if (tab == BottomTab.Inbox) unreadCount else 0,
                onClick = { onSelect(tab) },
            )
        }
    }
}

@Composable
private fun BottomItem(
    tab: BottomTab,
    selected: Boolean,
    unread: Int,
    onClick: () -> Unit,
) {
    val targetTint = if (selected) MaterialTheme.colorScheme.onBackground else AppColors.GrayMain
    val tint by animateColorAsState(
        targetValue = targetTint,
        animationSpec = tween(MotionTiming.STAGGER_MS * 3, easing = MotionTiming.EaseStandard),
        label = "tabTint",
    )
    val interactionSource = remember { MutableInteractionSource() }
    val view = LocalView.current

    // Haptic tick + pulse every time the badge count changes (initial 0 → n
    // also ticks, matching `w4` being invoked from the count observer).
    LaunchedEffect(unread) {
        if (unread > 0) view.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
    ) {
        Box {
            Icon(tab.icon, contentDescription = tab.label, tint = tint, modifier = Modifier.size(30.dp))
            if (unread > 0) {
                PulseAnimation(trigger = unread) {
                    Box(
                        modifier = Modifier
                            .offset(x = 12.dp, y = (-6).dp)
                            .size(16.dp)
                            .background(AppColors.SystemNegative, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = unread.coerceAtMost(99).toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
        Text(
            text = tab.label,
            style = MaterialTheme.typography.labelMedium,
            color = tint,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
