package com.tempmail.clone.data.repository

import com.tempmail.clone.data.local.PreferenceManager
import com.tempmail.clone.data.remote.PremiumApi
import com.tempmail.clone.data.remote.model.PushUpdateBody
import com.tempmail.clone.util.ApiError
import com.tempmail.clone.util.Resource
import kotlinx.coroutines.flow.first

/**
 * Placeholder for the original `SubscriptionRepository`
 * (Google Play Billing 8.0.0 + `user.activation` / `subscription.update` RPC).
 *
 * Billing is intentionally NOT wired here so the clone ships without the
 * original's Play Console products. The purchase products recovered from
 * `BillingConstants` are listed in [plans]; hook a BillingClient/RevenueCat
 * implementation in [activate] when you want it live.
 */
class SubscriptionRepository(
    private val premiumApi: PremiumApi,
    private val prefs: PreferenceManager,
) {

    data class Plan(val sku: String, val label: String, val months: Int, val trial: Boolean)

    val plans: List<Plan> = listOf(
        Plan("subscription_one_week", "1 Week", 0, trial = false),
        Plan("subscription_monthly_trial", "1 Month (Free Trial)", 1, trial = true),
        Plan("subscription_monthly", "1 Month", 1, trial = false),
        Plan("subscription_three_months", "3 Months", 3, trial = false),
        Plan("subscription_six_month", "6 Months", 6, trial = false),
        Plan("subscription_annual", "12 Months", 12, trial = false),
    )

    /** Premium-only feature bullets shown on the paywall. */
    val premiumFeatures: List<String> = listOf(
        "Ad-free",
        "Autofill in forms",
        "Connect own custom domain",
        "Custom email",
        "Extended email storage",
        "Multiple mailboxes",
        "Premium domains",
        "Premium support",
    )

    /**
     * Called after a successful Play Billing purchase with the purchase token.
     * The real implementation posts `user.activation` (first purchase) or
     * `subscription.update` (renewal) and stores the returned `sid`.
     */
    suspend fun activate(payToken: String): Resource<String> {
        // TODO: wire Google Play Billing, then send payToken to the backend.
        return Resource.Error(ApiError(1001, "Billing is not wired in the clone"))
    }

    /** Toggle push notifications for the premium account (`push.update`). */
    suspend fun updatePush(enabled: Boolean): Resource<Unit> {
        val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
        return try {
            val response = premiumApi.pushUpdate(PushUpdateBody(sid, enabled))
            if (response.isSuccessful && response.body()?.error == null) {
                Resource.Success(Unit)
            } else {
                Resource.Error(ApiError(response.code(), "Update failed"))
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }
}
