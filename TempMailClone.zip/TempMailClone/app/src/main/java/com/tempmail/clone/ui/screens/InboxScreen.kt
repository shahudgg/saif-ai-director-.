package com.tempmail.clone.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowRight
import androidx.compose.material.icons.filled.Attachment
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tempmail.clone.data.local.EmailEntity
import com.tempmail.clone.ui.AppViewModel
import com.tempmail.clone.ui.anim.MotionTiming
import com.tempmail.clone.ui.anim.OwlRefreshableBox
import com.tempmail.clone.ui.anim.StaggeredItem
import com.tempmail.clone.ui.components.AppBottomBar
import com.tempmail.clone.ui.components.AppToolbar
import com.tempmail.clone.ui.components.BottomTab
import com.tempmail.clone.ui.theme.AppColors
import com.tempmail.clone.ui.theme.AppDimens
import com.tempmail.clone.util.formatRelativeTime
import com.tempmail.clone.util.fromName

/**
 * "Inbox" tab — mirrors `fragment_inbox.xml` + `mail_item.xml`:
 * mailbox spinner, pull-to-refresh, swipe actions (mark unread / delete),
 * unread dot, sender/subject/preview and the time + arrow.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(
    viewModel: AppViewModel,
    onOpenDrawer: () -> Unit,
    onOpenMail: (String) -> Unit,
    onSwitchTab: () -> Unit,
    onManage: () -> Unit,
    onPremium: () -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val emails = state.emails
    var spinnerOpen by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        AppToolbar(
            title = if (state.unreadCount > 0) "Inbox (${state.unreadCount})" else "Inbox",
            leftIcon = Icons.Filled.Menu,
            onLeftClick = onOpenDrawer,
            rightIcon = Icons.Filled.WorkspacePremium,
            onRightClick = onPremium,
        )

        // Mailbox selector (original DynamicSpinner).
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(AppDimens.CardRadius))
                    .clickable { spinnerOpen = true }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = state.mailbox?.fullEmailAddress ?: "No mailbox",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Icon(
                    Icons.Filled.ArrowRight,
                    contentDescription = null,
                    tint = AppColors.GrayMain,
                    modifier = Modifier
                        .size(18.dp)
                        .padding(start = 4.dp),
                )
            }
            DropdownMenu(expanded = spinnerOpen, onDismissRequest = { spinnerOpen = false }) {
                state.mailboxes.forEach { mailbox ->
                    DropdownMenuItem(
                        text = { Text(mailbox.fullEmailAddress) },
                        onClick = {
                            spinnerOpen = false
                            viewModel.switchMailbox(mailbox)
                        },
                    )
                }
                if (state.mailboxes.isEmpty()) {
                    DropdownMenuItem(text = { Text("No mailboxes") }, onClick = { spinnerOpen = false })
                }
            }
        }

        OwlRefreshableBox(
            isRefreshing = state.refreshing,
            onRefresh = { viewModel.refreshInbox() },
            modifier = Modifier.weight(1f),
        ) {
            if (emails.isEmpty()) {
                EmptyInbox(
                    address = state.mailbox?.fullEmailAddress,
                    isRefreshing = state.refreshing,
                    onRefresh = { viewModel.refreshInbox() },
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 4.dp),
                ) {
                    itemsIndexed(emails, key = { _, it -> it.eid }) { index, email ->
                        StaggeredItem(key = email.eid, index = index) {
                            MailRow(
                                email = email,
                                onClick = {
                                    viewModel.openEmail(email)
                                    onOpenMail(email.eid)
                                },
                                onToggleRead = { viewModel.toggleRead(email) },
                                onDelete = { viewModel.deleteEmail(email) },
                            )
                        }
                    }
                }
            }
        }

        AppBottomBar(
            selected = BottomTab.Inbox,
            unreadCount = state.unreadCount,
            onSelect = { tab ->
                when (tab) {
                    BottomTab.Email -> onSwitchTab()
                    BottomTab.Manage -> onManage()
                    BottomTab.Inbox -> Unit
                }
            },
        )
    }
}

@Composable
private fun EmptyInbox(address: String?, isRefreshing: Boolean, onRefresh: () -> Unit) {
    // `InboxFragment` drops the Refresh button out of the envelope at ~8% of the
    // pull and pops it back at ~82% (300ms translateY + alpha).
    val buttonShown by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isRefreshing) 0f else 1f,
        animationSpec = tween(MotionTiming.SPINNER_MS, easing = MotionTiming.EaseOutCubic),
        label = "emptyRefreshButton",
    )
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Icon(
                Icons.Filled.MarkEmailRead,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(120.dp),
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "No emails yet",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Text(
                text = "Emails sent to ${address ?: "your address"} appear here.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier
                    .graphicsLayer {
                        alpha = buttonShown
                        translationY = (1f - buttonShown) * 500f
                    }
                    .clip(RoundedCornerShape(AppDimens.ButtonRadius))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .clickable(onClick = onRefresh)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Cached, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(6.dp))
                Text("Refresh", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MailRow(
    email: EmailEntity,
    onClick: () -> Unit,
    onToggleRead: () -> Unit,
    onDelete: () -> Unit,
) {
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            when (value) {
                SwipeToDismissBoxValue.StartToEnd -> { onToggleRead(); false }
                SwipeToDismissBoxValue.EndToStart -> { onDelete(); false }
                SwipeToDismissBoxValue.Settled -> false
            }
        },
    )

    // `MailListAdapter` guards re-taps within 500ms so a double tap can't open
    // the same message twice.
    var lastTap by remember { mutableLongStateOf(0L) }
    val guardedClick: () -> Unit = {
        val now = System.currentTimeMillis()
        if (now - lastTap >= 500L) {
            lastTap = now
            onClick()
        }
    }

    SwipeToDismissBox(
        state = dismissState,
        modifier = Modifier.fillMaxWidth(),
        backgroundContent = {
            val start = dismissState.dismissDirection == SwipeToDismissBoxValue.StartToEnd
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = AppDimens.MailHorizontalMargin, vertical = 0.dp)
                    .background(
                        color = if (start) AppColors.SystemPositive else AppColors.SystemNegative,
                        shape = RoundedCornerShape(AppDimens.CardRadius),
                    )
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (start) {
                    Icon(Icons.Filled.MarkEmailUnread, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.size(8.dp))
                    Text("Mark Unread", color = Color.White, style = MaterialTheme.typography.labelMedium)
                } else {
                    Spacer(Modifier.weight(1f))
                    Text("Delete", color = Color.White, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.size(8.dp))
                    Icon(Icons.Filled.Delete, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        },
    ) {
        MailCard(email = email, onClick = guardedClick)
    }
}

@Composable
private fun MailCard(email: EmailEntity, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = AppDimens.MailHorizontalMargin, vertical = 3.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(AppDimens.CardRadius))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!email.isChecked) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape),
                )
                Spacer(Modifier.size(3.dp))
            }
            Text(
                text = fromName(email.fromField).ifBlank { "Unknown sender" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (email.isChecked) FontWeight.Normal else FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 10.dp),
            )
            Text(
                text = formatRelativeTime(email.timestampMs),
                style = MaterialTheme.typography.labelMedium,
                color = AppColors.GrayMain,
            )
            Icon(
                Icons.Filled.ArrowRight,
                contentDescription = null,
                tint = AppColors.GrayMain,
                modifier = Modifier
                    .size(16.dp)
                    .padding(start = 2.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = email.subject.orEmpty().ifBlank { "(no subject)" },
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(1.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = email.preview.orEmpty(),
                style = MaterialTheme.typography.bodyLarge,
                color = AppColors.GrayMain,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (email.attachmentsCount > 0) {
                Icon(
                    Icons.Filled.Attachment,
                    contentDescription = "Attachments",
                    tint = AppColors.GrayMain,
                    modifier = Modifier
                        .size(16.dp)
                        .padding(start = 8.dp),
                )
            }
        }
    }
}
