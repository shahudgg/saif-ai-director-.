package com.tempmail.clone.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tempmail.clone.data.local.MailboxEntity
import com.tempmail.clone.ui.AppViewModel
import com.tempmail.clone.ui.anim.StaggeredItem
import com.tempmail.clone.ui.components.AppBottomBar
import com.tempmail.clone.ui.components.AppToolbar
import com.tempmail.clone.ui.components.BottomTab
import com.tempmail.clone.ui.theme.AppColors
import com.tempmail.clone.ui.theme.AppDimens

/**
 * "Manage" tab — mirrors `fragment_switch_email.xml` + `fragment_mailboxes.xml`
 * + `mailbox_item.xml`: active/default address card, every mailbox with an
 * expiry status and a per-card "Inbox" button, plus create/addresses actions.
 */
@Composable
fun SwitchMailboxScreen(
    viewModel: AppViewModel,
    onOpenDrawer: () -> Unit,
    onOpenInbox: () -> Unit,
    onCreate: () -> Unit,
    onEmailAddresses: () -> Unit,
    onPremium: () -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        AppToolbar(
            title = "Manage",
            leftIcon = Icons.Filled.Menu,
            onLeftClick = onOpenDrawer,
            rightIcon = Icons.Filled.WorkspacePremium,
            onRightClick = onPremium,
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = onCreate,
                    shape = RoundedCornerShape(AppDimens.ButtonRadius),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White,
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Create New")
                }
                Button(
                    onClick = onEmailAddresses,
                    shape = RoundedCornerShape(AppDimens.ButtonRadius),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.primary,
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                ) {
                    Text("Addresses")
                }
            }

            if (state.mailboxes.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No mailboxes", color = AppColors.GrayMain)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(state.mailboxes, key = { _, it -> it.fullEmailAddress }) { index, mailbox ->
                        StaggeredItem(key = mailbox.fullEmailAddress, index = index) {
                            MailboxCard(
                                mailbox = mailbox,
                                onClick = { viewModel.switchMailbox(mailbox) },
                                onDelete = { viewModel.deleteMailbox(mailbox) },
                                onInbox = onOpenInbox,
                            )
                        }
                    }
                }
            }
        }

        AppBottomBar(
            selected = BottomTab.Manage,
            unreadCount = state.unreadCount,
            onSelect = { tab ->
                when (tab) {
                    BottomTab.Email, BottomTab.Inbox -> onOpenInbox()
                    BottomTab.Manage -> Unit
                }
            },
        )
    }
}

@Composable
private fun MailboxCard(
    mailbox: MailboxEntity,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onInbox: () -> Unit,
) {
    val expired = mailbox.isExpiredTime()
    val expiringSoon = mailbox.isExpiredSoon()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(AppDimens.CardRadius))
            .padding(AppDimens.MailboxItemPadding),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            if (mailbox.isDefault) {
                Icon(Icons.Filled.CheckCircle, contentDescription = "Active", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            } else if (mailbox.isPremium) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = AppColors.GrayMain, modifier = Modifier.size(18.dp))
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 10.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = mailbox.fullEmailAddress,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Icon(
                        Icons.Filled.ContentCopy,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .padding(start = 6.dp)
                            .size(16.dp),
                    )
                }
                val status = when {
                    expired -> "This mailbox is not active anymore"
                    expiringSoon -> "Mailbox will be deactivate soon"
                    mailbox.isPremium -> "Own private domain / Premium domain"
                    else -> "Disposable address"
                }
                Text(
                    text = status,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (expired) AppColors.SystemNegative else AppColors.GrayMain,
                    modifier = Modifier.padding(top = 3.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = onDelete, enabled = !mailbox.isDefault, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Delete", tint = AppColors.GrayMain, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier
                .padding(start = 10.dp)
                .background(AppColors.ButtonMailCardDefaultDay, RoundedCornerShape(AppDimens.SmallRadius))
                .clickable(onClick = onInbox)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Inbox, contentDescription = null, tint = AppColors.GrayMain, modifier = Modifier.size(16.dp))
            Text(
                text = "Inbox",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(start = 12.dp),
            )
        }
    }
}
