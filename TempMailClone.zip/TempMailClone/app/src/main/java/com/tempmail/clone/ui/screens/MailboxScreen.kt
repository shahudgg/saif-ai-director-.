package com.tempmail.clone.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tempmail.clone.ui.AppViewModel
import com.tempmail.clone.ui.anim.FireOverlay
import com.tempmail.clone.ui.anim.MotionTiming
import com.tempmail.clone.ui.anim.NewMessagePill
import com.tempmail.clone.ui.components.AppBottomBar
import com.tempmail.clone.ui.components.AppToolbar
import com.tempmail.clone.ui.components.BottomTab
import com.tempmail.clone.ui.theme.AppColors
import com.tempmail.clone.ui.theme.AppDimens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * "Email" tab — mirrors `fragment_email_address.xml` + `envelope_view.xml`:
 * big white envelope card holding the temporary address + green "Copy email"
 * button, a "Change" row and the storage note.
 *
 * Animations reproduce `MailboxFragmentPresenter`:
 *  - press → scale 1.0 → 0.9 (200ms) + haptic, label becomes "Copied", icon a check;
 *  - after 1500ms the label/icon revert and the button scales back (200ms);
 *  - "Change" plays the fire sweep; at 75% the card does a 0.9→1.0 bounce while
 *    the address swaps (the original `scaleDownAndUpAnimation`).
 */
@Composable
fun MailboxScreen(
    viewModel: AppViewModel,
    onOpenDrawer: () -> Unit,
    onOpenInbox: () -> Unit,
    onPremium: () -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    val animate = state.animations

    val address = state.mailbox?.fullEmailAddress
    val mailbox = state.mailbox

    var copied by remember { mutableStateOf(false) }
    val copyScale = remember { Animatable(1f) }

    var fireVisible by remember { mutableStateOf(false) }
    val envelopeScale = remember { Animatable(1f) }

    // "New message" pill — shown briefly when the unread count increases, then
    // faded out (the original reveals `tvNewMessage` with a 300ms alpha).
    var pillVisible by remember { mutableStateOf(false) }
    var lastUnread by remember { mutableStateOf(state.unreadCount) }
    LaunchedEffect(state.unreadCount) {
        if (state.unreadCount > lastUnread) {
            pillVisible = true
            delay(3000L)
            pillVisible = false
        }
        lastUnread = state.unreadCount
    }

    // Revert the "Copied" state after 1500ms, then scale back up (200ms) only if
    // still attached — the original guards on `isAttachedToWindow`.
    LaunchedEffect(copied) {
        if (copied) {
            delay(MotionTiming.COPY_RESTORE_DELAY_MS)
            copied = false
            if (animate) {
                copyScale.animateTo(1f, tween(MotionTiming.COPY_RESTORE_MS, easing = MotionTiming.EaseOutCubic))
            } else {
                copyScale.snapTo(1f)
            }
        }
    }

    val onCopy: () -> Unit = {
        if (!address.isNullOrBlank()) {
            copyToClipboard(context, address)
            view.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK)
            copied = true
            if (animate) {
                scope.launch {
                    copyScale.snapTo(1f)
                    copyScale.animateTo(0.9f, tween(MotionTiming.COPY_PRESS_MS, easing = MotionTiming.EaseOutCubic))
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
        ) {
            AppToolbar(
                title = "Email",
                leftIcon = Icons.Filled.Menu,
                onLeftClick = onOpenDrawer,
                rightIcon = Icons.Filled.WorkspacePremium,
                onRightClick = onPremium,
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(50.dp))

                // Envelope card (recreated; original used a drawing + Lottie flag).
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(0.98f)
                        .graphicsLayer {
                            scaleX = envelopeScale.value
                            scaleY = envelopeScale.value
                        }
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surface),
                ) {
                    Icon(
                        Icons.Filled.MoreVert,
                        contentDescription = null,
                        tint = AppColors.GrayMain,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp),
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        if (address.isNullOrBlank()) {
                            Text(
                                text = "Creating your address...",
                                style = MaterialTheme.typography.headlineMedium,
                                textAlign = TextAlign.Center,
                            )
                        } else {
                            Text(
                                text = address,
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                            )
                            Spacer(Modifier.height(7.dp))
                            Text(
                                text = "Your Temporary Email Address",
                                style = MaterialTheme.typography.bodyLarge,
                                color = AppColors.GrayMain,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                    Button(
                        onClick = onCopy,
                        enabled = !address.isNullOrBlank(),
                        shape = RoundedCornerShape(AppDimens.ButtonRadius),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = androidx.compose.ui.graphics.Color.White,
                        ),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 25.dp)
                            .padding(bottom = 27.dp)
                            .fillMaxWidth()
                            .height(52.dp)
                            .graphicsLayer {
                                scaleX = copyScale.value
                                scaleY = copyScale.value
                            },
                    ) {
                        Icon(
                            imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                            contentDescription = null,
                            modifier = Modifier
                                .size(16.dp)
                                .graphicsLayer { alpha = 0.7f },
                        )
                        Spacer(Modifier.size(6.dp))
                        Text(
                            text = if (copied) "Copied" else "Copy email",
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .padding(top = 20.dp)
                        .clip(RoundedCornerShape(AppDimens.ButtonRadius))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) {
                            if (animate) {
                                fireVisible = true
                            } else {
                                viewModel.createNewMailbox()
                            }
                        }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Filled.Autorenew, contentDescription = null, tint = AppColors.GrayMain, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text(
                        text = "Change",
                        style = MaterialTheme.typography.titleMedium,
                        color = AppColors.GrayMain,
                    )
                }

                Spacer(Modifier.height(10.dp))

                Text(
                    text = when {
                        mailbox == null -> "Free emails are stored for up to 1 hour, while Premium emails last up to 30 days."
                        mailbox.isExpiredTime() -> "This mailbox is not active anymore"
                        mailbox.isExpiredSoon() -> "Mailbox will be deactivate soon"
                        else -> "Free emails are stored for up to 1 hour, while Premium emails last up to 30 days."
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (mailbox?.isExpiredTime() == true) AppColors.SystemNegative else AppColors.GrayMain,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onOpenInbox,
                    shape = RoundedCornerShape(AppDimens.ButtonRadius),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = androidx.compose.ui.graphics.Color.White,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(AppDimens.MainButtonHeight),
                ) {
                    Text("Inbox", fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(24.dp))
            }

            if (state.loading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.primary)
            }

            AppBottomBar(
                selected = BottomTab.Email,
                unreadCount = state.unreadCount,
                onSelect = { tab ->
                    when (tab) {
                        BottomTab.Inbox, BottomTab.Manage -> onOpenInbox()
                        BottomTab.Email -> Unit
                    }
                },
            )
        }

        // New-message pill (fragment_email_address.xml `tvNewMessage`).
        NewMessagePill(
            visible = pillVisible,
            text = "New message",
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 64.dp),
        )

        // Fire sweep on "Change": the address swap fires at 75% of the track
        // (`MailboxFragmentPresenter.playFireAnimation`) with a card bounce.
        FireOverlay(
            visible = fireVisible,
            onReveal = {
                viewModel.createNewMailbox()
                if (animate) {
                    scope.launch {
                        envelopeScale.snapTo(0.9f)
                        envelopeScale.animateTo(1f, tween(MotionTiming.BOUNCE_MS, easing = MotionTiming.EaseOutCubic))
                    }
                }
            },
            onFinished = { fireVisible = false },
        )
    }
}

internal fun copyToClipboard(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    manager.setPrimaryClip(ClipData.newPlainText("Temp Mail", text))
}
