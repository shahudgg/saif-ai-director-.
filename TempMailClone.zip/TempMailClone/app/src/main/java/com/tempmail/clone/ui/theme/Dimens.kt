package com.tempmail.clone.ui.theme

import androidx.compose.ui.unit.dp

/** Spacing tokens copied from the original res/values/dimens.xml. */
object AppDimens {
    val DefaultMargin = 8.dp
    val ScreenHorizontalMargin = 16.dp
    val EmailScreenVerticalMargin = 16.dp
    val CreateEmailMargin = 16.dp

    /** Rounded corner used by every primary card / button (`snackbar_radius` = 17dp). */
    val CardRadius = 17.dp
    val ButtonRadius = 14.dp
    val SmallRadius = 11.dp

    val ButtonMainPaddingVertical = 12.dp
    val ButtonChangeMarginTop = 13.dp
    val ButtonCheckEmailMarginTop = 14.dp
    val ButtonCopyMarginTop = 12.dp
    val ButtonEditMarginTop = 8.dp
    val ChangeEmailBlockTopMargin = 10.dp
    val ChangeEmailMessageTopMargin = 5.dp

    val MailHorizontalMargin = 7.dp
    val MailboxItemPadding = 12.dp
    val InboxRefreshButtonMargins = 14.dp

    val ToolbarHeight = 40.dp
    val ToolbarTopMargin = 8.dp
    val MenuButtonSize = 40.dp
    val MainButtonHeight = 52.dp
}
