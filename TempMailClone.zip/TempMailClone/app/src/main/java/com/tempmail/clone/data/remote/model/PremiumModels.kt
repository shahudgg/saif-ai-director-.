package com.tempmail.clone.data.remote.model

import com.google.gson.annotations.SerializedName

/**
 * Premium JSON-RPC models — recovered from
 * `com.tempmail.data.api.models.answers.*` and `...requests.*`.
 * Served by https://papi2.temp-mail.org (`POST /rpc/`).
 */

/** Base RPC envelope: { "id": 1, "jsonrpc": 2.0, "method": "...", "params": {...} } */
open class RpcBody(method: String? = null) {
    var id: Int = 1
    var jsonrpc: Double = 2.0
    var method: String? = method
}

/** RPC error object embedded in every wrapper. */
data class RpcError(
    @SerializedName("code") val code: Int? = null,
    @SerializedName("data") val data: Any? = null,
    @SerializedName("errorName") val errorName: String? = null,
    @SerializedName("message") val message: String? = null,
    @SerializedName("subCode") val subCode: Int? = null,
)

/** Base RPC response: { "id", "jsonrpc", "error" } */
open class RpcWrapper {
    @SerializedName("error") var error: RpcError? = null
    @SerializedName("id") var id: String? = null
    @SerializedName("jsonrpc") var jsonrpc: String? = null
}

// ---- getdomains (DomainTable) -------------------------------------------------
data class DomainExpire(
    @SerializedName("domain") var domain: String? = null,
    @SerializedName("exp") var exp: Long? = null,
    @SerializedName("status") var status: String? = null,
    @SerializedName("type") var type: String? = null,
) : Comparable<DomainExpire> {
    override fun compareTo(other: DomainExpire): Int =
        (domain ?: "").compareTo(other.domain ?: "", ignoreCase = true)
}

/** `mailbox.listv2` / `mailbox.messages` payload. */
data class ExtendedMail(
    @SerializedName("mail_id") var mailId: String? = null,
    @SerializedName("mail_from") var mailFrom: String? = null,
    @SerializedName("mail_subject") var mailSubject: String? = null,
    @SerializedName("mail_timestamp") var mailTimestamp: Double = 0.0,
    @SerializedName("mail_text") var mailText: String? = null,
    @SerializedName("mail_text_only") var mailTextOnly: String? = null,
    @SerializedName("mail_html") var mailHtml: String? = null,
    @SerializedName("mail_attachments") var attachmentsCount: Int = 0,
    @SerializedName("preview") var preview: String? = null,
    @SerializedName("mail_attachments_list") var attachmentInfo: List<AttachmentInfo>? = null,
) {
    data class AttachmentInfo(
        @SerializedName("filename") val filename: String? = null,
        @SerializedName("_id") val id: Int = 0,
        @SerializedName("mimetype") val mimeType: String? = null,
        @SerializedName("size") val size: Long = 0L,
        @SerializedName("cid") val cid: String? = null,
    )
}
