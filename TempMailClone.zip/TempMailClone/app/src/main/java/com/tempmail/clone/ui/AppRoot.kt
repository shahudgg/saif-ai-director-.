package com.tempmail.clone.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.tempmail.clone.App
import com.tempmail.clone.ui.anim.MotionTiming
import com.tempmail.clone.ui.components.AppDrawer
import com.tempmail.clone.ui.screens.ContactScreen
import com.tempmail.clone.ui.screens.CreateMailboxScreen
import com.tempmail.clone.ui.screens.EmailAddressesScreen
import com.tempmail.clone.ui.screens.FaqScreen
import com.tempmail.clone.ui.screens.HelpCenterScreen
import com.tempmail.clone.ui.screens.InboxScreen
import com.tempmail.clone.ui.screens.MailScreen
import com.tempmail.clone.ui.screens.MailboxScreen
import com.tempmail.clone.ui.screens.OnboardingScreen
import com.tempmail.clone.ui.screens.PremiumScreen
import com.tempmail.clone.ui.screens.PrivateDomainsScreen
import com.tempmail.clone.ui.screens.QrScreen
import com.tempmail.clone.ui.screens.SplashScreen
import com.tempmail.clone.ui.screens.SwitchMailboxScreen
import kotlinx.coroutines.launch

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val app = context.applicationContext as App
    val viewModel = sharedViewModel(app)
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val state by viewModel.state.collectAsStateWithLifecycle()
    val backStackEntry by navController.currentBackStackEntryAsState()

    val openDrawer: () -> Unit = { scope.launch { drawerState.open() } }
    val closeDrawer: () -> Unit = { scope.launch { drawerState.close() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = backStackEntry?.destination?.route.orEmpty() in
            setOf(Routes.MAILBOX, Routes.INBOX, Routes.SWITCH),
        drawerContent = {
            AppDrawer(
                state = state,
                onClose = closeDrawer,
                onPremium = { closeDrawer(); navController.navigate(Routes.PREMIUM) },
                onCustomEmail = { closeDrawer(); navController.navigate(Routes.CREATE_MAILBOX) },
                onPrivateDomains = { closeDrawer(); navController.navigate(Routes.PRIVATE_DOMAINS) },
                onWebPremium = { closeDrawer(); navController.navigate(Routes.QR) },
                onHelpCenter = { closeDrawer(); navController.navigate(Routes.HELP_CENTER) },
                onRateUs = {
                    closeDrawer()
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${context.packageName}")),
                        )
                    }
                },
                onRestart = {
                    closeDrawer()
                    (context as? Activity)?.recreate()
                },
                onDarkMode = viewModel::setDarkMode,
                onAnimations = viewModel::setAnimations,
                onNotifications = viewModel::setNotifications,
                onAutofill = viewModel::setAutofill,
                onLanguage = { code -> viewModel.setLanguage(code) },
            )
        },
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(androidx.compose.material3.MaterialTheme.colorScheme.background)
                .statusBarsPadding(),
        ) {
            // Navigation cross-fade — matches `@anim/fade_in` / `@anim/fade_out`
            // (250ms) carried by the graph's `global_to_nav_inbox` action.
            val navFadeMs = MotionTiming.NAV_FADE_MS
            val navEnter = fadeIn(tween(navFadeMs, easing = LinearEasing))
            val navExit = fadeOut(tween(navFadeMs, easing = LinearEasing))

            NavHost(
                navController = navController,
                startDestination = Routes.SPLASH,
                enterTransition = { navEnter },
                exitTransition = { navExit },
                popEnterTransition = { navEnter },
                popExitTransition = { navExit },
            ) {
                composable(Routes.SPLASH) {
                    SplashScreen(
                        onFinished = {
                            navController.navigate(if (state.onboarded == true) Routes.MAILBOX else Routes.ONBOARDING) {
                                popUpTo(Routes.SPLASH) { inclusive = true }
                            }
                        },
                    )
                }
                composable(Routes.ONBOARDING) {
                    OnboardingScreen(
                        onContinue = {
                            viewModel.completeOnboarding()
                            navController.navigate(Routes.MAILBOX) {
                                popUpTo(Routes.ONBOARDING) { inclusive = true }
                            }
                        },
                    )
                }
                composable(Routes.MAILBOX) {
                    MailboxScreen(
                        viewModel = viewModel,
                        onOpenDrawer = openDrawer,
                        onOpenInbox = {
                            navController.navigate(Routes.INBOX) { launchSingleTop = true }
                        },
                        onPremium = { navController.navigate(Routes.PREMIUM) },
                    )
                }
                composable(Routes.INBOX) {
                    InboxScreen(
                        viewModel = viewModel,
                        onOpenDrawer = openDrawer,
                        onOpenMail = { id -> navController.navigate(Routes.mail(id)) },
                        onSwitchTab = { navController.navigate(Routes.MAILBOX) { launchSingleTop = true } },
                        onManage = { navController.navigate(Routes.SWITCH) { launchSingleTop = true } },
                        onPremium = { navController.navigate(Routes.PREMIUM) },
                    )
                }
                composable(Routes.SWITCH) {
                    SwitchMailboxScreen(
                        viewModel = viewModel,
                        onOpenDrawer = openDrawer,
                        onOpenInbox = { navController.navigate(Routes.INBOX) { launchSingleTop = true } },
                        onCreate = { navController.navigate(Routes.CREATE_MAILBOX) },
                        onEmailAddresses = { navController.navigate(Routes.EMAIL_ADDRESSES) },
                        onPremium = { navController.navigate(Routes.PREMIUM) },
                    )
                }
                composable(
                    route = "${Routes.MAIL}?emailId={emailId}",
                    arguments = listOf(navArgument("emailId") { type = NavType.StringType; defaultValue = "" }),
                ) { entry ->
                    MailScreen(
                        viewModel = viewModel,
                        emailId = entry.arguments?.getString("emailId").orEmpty(),
                        onBack = { navController.popBackStack() },
                    )
                }
                composable(Routes.CREATE_MAILBOX) {
                    CreateMailboxScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onPremium = { navController.navigate(Routes.PREMIUM) },
                    )
                }
                composable(Routes.PREMIUM) {
                    PremiumScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                    )
                }
                composable(Routes.PRIVATE_DOMAINS) {
                    PrivateDomainsScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                        onPremium = { navController.navigate(Routes.PREMIUM) },
                    )
                }
                composable(Routes.EMAIL_ADDRESSES) {
                    EmailAddressesScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() },
                    )
                }
                composable(Routes.HELP_CENTER) {
                    HelpCenterScreen(
                        onBack = { navController.popBackStack() },
                        onFaq = { navController.navigate(Routes.FAQ) },
                        onContact = { navController.navigate(Routes.CONTACT) },
                    )
                }
                composable(Routes.FAQ) {
                    FaqScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.CONTACT) {
                    ContactScreen(onBack = { navController.popBackStack() })
                }
                composable(Routes.QR) {
                    QrScreen(
                        onBack = { navController.popBackStack() },
                        onPremium = { navController.navigate(Routes.PREMIUM) },
                    )
                }
            }
        }
    }
}
