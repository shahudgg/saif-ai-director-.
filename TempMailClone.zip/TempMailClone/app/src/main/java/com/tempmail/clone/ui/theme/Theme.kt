package com.tempmail.clone.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = AppColors.ColorPrimary,
    onPrimary = Color.White,
    primaryContainer = AppColors.ColorPrimaryVariant,
    onPrimaryContainer = AppColors.ColorPrimaryDark,
    secondary = AppColors.SystemNeutral,
    onSecondary = Color.White,
    background = AppColors.MainBackgroundDay,
    onBackground = AppColors.PrimaryTextDay,
    surface = AppColors.BackgroundWhiteDay,
    onSurface = AppColors.PrimaryTextDay,
    surfaceVariant = AppColors.LightGrayDay,
    onSurfaceVariant = AppColors.GrayMain,
    error = AppColors.SystemNegative,
    onError = Color.White,
    outline = AppColors.GrayStrong,
)

private val DarkColors = darkColorScheme(
    primary = AppColors.ColorPrimary,
    onPrimary = Color.White,
    primaryContainer = AppColors.LightGreenNight,
    onPrimaryContainer = AppColors.ColorPrimary,
    secondary = AppColors.SystemNeutral,
    onSecondary = Color.Black,
    background = AppColors.MainBackgroundNight,
    onBackground = AppColors.PrimaryTextNight,
    surface = AppColors.BackgroundWhiteNight,
    onSurface = AppColors.PrimaryTextNight,
    surfaceVariant = AppColors.LightGrayNight,
    onSurfaceVariant = AppColors.GrayMain,
    error = AppColors.SystemNegative,
    onError = Color.White,
    outline = AppColors.GrayStrong,
)

/**
 * @param darkOverride null = follow system, true/false = user's explicit choice
 *   (the drawer "Dark mode" switch, stored as "is_dark_mode_enabled").
 */
@Composable
fun TempMailTheme(
    darkOverride: Boolean? = null,
    content: @Composable () -> Unit,
) {
    val dark = darkOverride ?: isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
