package com.tempmail.clone.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tempmail.clone.App

/** Provides the single shared [AppViewModel] for the whole graph. */
@Composable
fun sharedViewModel(app: App): AppViewModel {
    val factory = remember(app) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                AppViewModel(app) as T
        }
    }
    return viewModel(factory = factory)
}
