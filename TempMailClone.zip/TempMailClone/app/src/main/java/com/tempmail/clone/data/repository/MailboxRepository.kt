package com.tempmail.clone.data.repository

import com.tempmail.clone.data.local.MailboxDao
import com.tempmail.clone.data.local.MailboxEntity
import com.tempmail.clone.data.local.PreferenceManager
import com.tempmail.clone.data.remote.FreeApi
import com.tempmail.clone.data.remote.PremiumApi
import com.tempmail.clone.data.remote.model.DeleteEmailBody
import com.tempmail.clone.data.remote.model.NewMailboxBody
import com.tempmail.clone.util.ApiError
import com.tempmail.clone.util.Constants
import com.tempmail.clone.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.Calendar
import java.util.Random

/**
 * Mailbox lifecycle. Ported from `com.tempmail.data.repository.MailboxRepository`.
 * Free flow:  POST /mailbox  →  save token, store a 10-minute mailbox.
 * Premium flow: RPC `mailbox.new` (needs an active `sid`).
 */
class MailboxRepository(
    private val freeApi: FreeApi,
    private val premiumApi: PremiumApi,
    private val mailboxDao: MailboxDao,
    private val prefs: PreferenceManager,
) {

    fun observeMailboxes(): Flow<List<MailboxEntity>> = mailboxDao.observeMailboxes()
    fun observeDefault(): Flow<MailboxEntity?> = mailboxDao.observeDefault()
    suspend fun mailboxes(): List<MailboxEntity> = mailboxDao.mailboxes()
    suspend fun current(): MailboxEntity? = mailboxDao.defaultMailbox()

    /** Create (or refresh) the free mailbox for the stored token. */
    suspend fun createNewMailboxFree(): Resource<MailboxEntity> {
        return try {
            val token = prefs.currentFreeToken()
            val auth = token?.let { "Bearer $it" } ?: ""
            val response = freeApi.createMailbox(auth)
            val body = response.body()
            if (!response.isSuccessful || body?.mailbox == null) {
                Resource.Error(mapError(response.code(), body?.errorName, body?.errorMessage))
            } else {
                prefs.setFreeToken(body.token)
                prefs.setLastCheck(System.currentTimeMillis())
                val entity = fromAddress(body.mailbox!!, premium = false, lifetimeMs = Constants.MAILBOX_LIFETIME_MS)
                mailboxDao.clearDefaults()
                mailboxDao.upsert(entity)
                Resource.Success(entity)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    /** Validate the current free token (GET /mailbox). */
    suspend fun verifyMailboxFree(): Resource<String> {
        return try {
            val token = prefs.currentFreeToken() ?: return Resource.Error(ApiError(401, "No token"))
            val response = freeApi.verifyMailbox("Bearer $token")
            val body = response.body()
            if (response.isSuccessful && body?.mailbox != null) {
                Resource.Success(body.mailbox!!)
            } else {
                Resource.Error(mapError(response.code(), body?.errorName, body?.errorMessage))
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    /** Premium: create a mailbox with a specific local part + domain. */
    suspend fun createNewMailboxPremium(local: String, domain: String): Resource<MailboxEntity> {
        val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
        return try {
            val response = premiumApi.createMailbox(NewMailboxBody(sid, local, domain))
            val wrapper = response.body()
            val error = wrapper?.error
            val email = wrapper?.result?.email
            if (!response.isSuccessful || error != null || email == null) {
                Resource.Error(ApiError(error?.code ?: response.code(), error?.message, error?.errorName, error?.subCode))
            } else {
                val entity = fromAddress(email, premium = true, lifetimeMs = 30L * 24 * 3600 * 1000)
                mailboxDao.clearDefaults()
                mailboxDao.upsert(entity)
                Resource.Success(entity)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    /** Random local part of 5–8 letters + digits (original `AppUtils.c`). */
    fun randomLocalPart(): String {
        val letters = "abcdefghijklmnopqrstuvwxyz"
        val digits = "0123456789"
        val rnd = Random()
        val len = 5 + rnd.nextInt(4)
        val sb = StringBuilder()
        repeat(len) { sb.append(letters[rnd.nextInt(letters.length)]) }
        repeat((10 - len).coerceAtLeast(1)) { sb.append(digits[rnd.nextInt(digits.length)]) }
        return sb.toString()
    }

    suspend fun setDefault(mailbox: MailboxEntity) {
        mailboxDao.clearDefaults()
        mailboxDao.setDefault(mailbox.fullEmailAddress)
    }

    suspend fun delete(mailbox: MailboxEntity): Resource<Unit> {
        val all = mailboxDao.mailboxes()
        if (all.size <= 1) {
            return Resource.Error(ApiError(6001, "You cannot delete the last mailbox"))
        }
        if (mailbox.isPremium) {
            val sid = prefs.sid.first()
            if (sid != null) {
                runCatching { premiumApi.deleteMailbox(DeleteEmailBody(sid, mailbox.fullEmailAddress)) }
            }
        }
        mailboxDao.delete(mailbox.fullEmailAddress)
        val remaining = mailboxDao.mailboxes()
        if (remaining.isNotEmpty() && remaining.none { it.isDefault }) {
            mailboxDao.setDefault(remaining.first().fullEmailAddress)
        }
        return Resource.Success(Unit)
    }

    suspend fun clearAll() {
        mailboxDao.clear()
    }

    private fun fromAddress(address: String, premium: Boolean, lifetimeMs: Long): MailboxEntity {
        val at = address.lastIndexOf('@')
        val prefix = if (at > 0) address.substring(0, at) else address
        val domain = if (at > 0) address.substring(at) else "@"
        val now = Calendar.getInstance().timeInMillis
        return MailboxEntity(
            fullEmailAddress = address,
            emailPrefix = prefix,
            domain = domain,
            isDefault = true,
            isPremium = premium,
            startTime = now,
            endTime = now + lifetimeMs,
        )
    }

    private fun mapError(code: Int, errorName: String?, message: String?): ApiError =
        ApiError(code = code, errorName = errorName, message = message ?: "Request failed")
}
