package com.tempmail.clone.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Colour tokens recreated from the original res/values/colors.xml +
 * res/values-night/colors.xml. Names follow the original resource names so the
 * Compose UI can be matched one-to-one against the decompiled layouts.
 */
object AppColors {

    // Brand (same in day / night).
    val ColorPrimary = Color(0xFF18CA88)
    val ColorPrimaryDark = Color(0xFF019C79)
    val ColorPrimaryVariant = Color(0xFFE6FFF6)

    // System semantic colours.
    val SystemPositive = Color(0xFF18CA88)
    val SystemNegative = Color(0xFFFF4F4F)
    val SystemNeutral = Color(0xFFFFB413)

    // Day-mode surfaces.
    val MainBackgroundDay = Color(0xFFEAEEF2)
    val BackgroundWhiteDay = Color(0xFFFFFFFF)
    val BackgroundSheeldDay = Color(0xFFFFFFFF)
    val LightGrayDay = Color(0xFFE1E4EC)
    val LightGreenDay = Color(0xFFD6FFF0)
    val GrayExtraLightDay = Color(0xFFF3F6F9)

    // Night-mode surfaces.
    val MainBackgroundNight = Color(0xFF303234)
    val BackgroundWhiteNight = Color(0xFF3C3E40)
    val BackgroundSheeldNight = Color(0xFF2A2C2D)
    val LightGrayNight = Color(0xFF3C3E40)
    val GrayExtraLightNight = Color(0xFF3C3E40)
    val LightGreenNight = Color(0x0D18CA88)

    // Text.
    val PrimaryTextDay = Color(0xFF000000)
    val PrimaryTextNight = Color(0xFFFFFFFF)
    val SecondaryText = Color(0xFFFFFFFF)
    val GrayMain = Color(0xFF96979F)
    val GrayStrong = Color(0xFF8D92A3)
    val ButtonTextColor = Color(0xFF585D6A)
    val UserInitialsText = Color(0xFF6C96F2)
    val UserInitialsBackground = Color(0xFFE6EFFF)

    val SystemNeutral10 = Color(0x1AFFB413)
    val SystemNeutral30 = Color(0x4DFFB413)

    val ButtonMailCardDefaultDay = Color(0xFFE1E4EC)
    val ButtonMailCardDefaultNight = Color(0xFF505153)
}
