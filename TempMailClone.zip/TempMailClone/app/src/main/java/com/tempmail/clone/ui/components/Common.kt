package com.tempmail.clone.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.tempmail.clone.ui.theme.AppColors
import com.tempmail.clone.ui.theme.AppDimens

/**
 * Circular toolbar button matching the original `menu_btn` style + the
 * `btn_circle_light_gray` / `btn_circle_system_neutral` backgrounds.
 */
@Composable
fun CircleIconButton(
    icon: ImageVector,
    onClick: () -> Unit,
    contentDescription: String? = null,
    background: Color = MaterialTheme.colorScheme.surfaceVariant,
    tint: Color = MaterialTheme.colorScheme.onBackground,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .size(AppDimens.MenuButtonSize)
            .clip(CircleShape)
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(20.dp),
        )
    }
}

/**
 * Toolbar matching `res/layout/toolbar_content.xml`: 40dp tall, a circular
 * left button (menu or back), a centred 18sp title and a circular amber
 * premium (crown) button on the right.
 */
@Composable
fun AppToolbar(
    title: String,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
    leftIcon: ImageVector? = null,
    onLeftClick: (() -> Unit)? = null,
    rightIcon: ImageVector? = null,
    onRightClick: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = AppDimens.ToolbarTopMargin)
            .height(AppDimens.ToolbarHeight)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        when {
            onBack != null -> CircleIconButton(Icons.Filled.ArrowBack, onBack, "Back")
            leftIcon != null && onLeftClick != null -> CircleIconButton(leftIcon, onLeftClick, "Menu")
            else -> Box(Modifier.size(AppDimens.MenuButtonSize))
        }
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
        )
        if (rightIcon != null && onRightClick != null) {
            CircleIconButton(
                icon = rightIcon,
                onClick = onRightClick,
                contentDescription = "Premium",
                background = AppColors.SystemNeutral10,
                tint = AppColors.SystemNeutral,
            )
        } else {
            Box(Modifier.size(AppDimens.MenuButtonSize))
        }
    }
}

/**
 * Drawer / settings row matching `style/btnMenuItem` + `ivMenuItem` + `tvMenuItem`
 * (12dp padding, 16dp icon tinted grey, optional amber PREMIUM badge, optional switch).
 */
@Composable
fun MenuRow(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    iconTint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    trailing: String? = null,
    switch: Boolean? = null,
    onToggle: ((Boolean) -> Unit)? = null,
    showDividerAbove: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        if (showDividerAbove) {
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = onClick != null) { onClick?.invoke() }
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(16.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 6.dp),
            )
            if (trailing != null) {
                Text(
                    text = trailing,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier
                        .clip(RoundedCornerShape(AppDimens.SmallRadius))
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                )
            }
            if (switch != null && onToggle != null) {
                Switch(
                    checked = switch,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary),
                )
            }
        }
    }
}

/** Green "ACTIVE"/premium pill matching `bg_primary_11dp`. */
@Composable
fun PremiumBadge(modifier: Modifier = Modifier) {
    Text(
        text = "PREMIUM",
        style = MaterialTheme.typography.labelSmall,
        color = Color.White,
        modifier = modifier
            .clip(RoundedCornerShape(AppDimens.SmallRadius))
            .background(MaterialTheme.colorScheme.primary)
            .padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

/**
 * Circular monogram avatar used in the mail header, matching
 * `circle_user_initiials_background` (light blue) + `user_initials_text_color`.
 */
@Composable
fun InitialsAvatar(initials: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(44.dp)
            .background(AppColors.UserInitialsBackground, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = initials,
            color = AppColors.UserInitialsText,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
