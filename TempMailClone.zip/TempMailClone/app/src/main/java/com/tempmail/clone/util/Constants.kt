package com.tempmail.clone.util

/**
 * Constants recovered from the original APK
 * (com.tempmail.utils.constants.Constants / ApiConstants).
 */
object Constants {
    /** Free mailboxes live for 10 minutes (Constants.f56391f == 600000L). */
    const val MAILBOX_LIFETIME_MS: Long = 10 * 60 * 1000L

    /** A mailbox is flagged "expiring soon" this long before it dies. */
    const val EXPIRE_SOON_THRESHOLD_MS: Long = 2 * 60 * 1000L

    /** Premium messages are stored for 30 days. */
    const val PREMIUM_STORAGE_DAYS = 30

    const val DB_NAME = "tempmail_db"

    /** Primary (premium) JSON-RPC gateway. */
    const val BASE_URL_PREMIUM = "https://papi2.temp-mail.org"

    /** Free REST gateway (create/verify mailbox + read messages). */
    const val BASE_URL_FREE = "https://mob2.temp-mail.org"

    /** Third gateway used by the original for the Web-Premium QR pairing. */
    const val URL_WEB_PREMIUM = "https://temp-mail.org"

    val RESERVED_NAMES = listOf(
        "abuse", "postmaster", "hostmaster", "webmaster", "admin", "support", "root",
        "billing", "compliance", "dev", "dns", "ftp", "inoc", "ispfeedback", "ispsupport",
        "list-request", "list", "maildaemon", "noc", "no-reply", "noreply", "", "phish",
        "phishing", "privacy", "registrar", "security", "spam", "sysadmin", "undisclosed-recipients",
        "unsubscribe", "usenet", "uucp", "www",
    )
}
