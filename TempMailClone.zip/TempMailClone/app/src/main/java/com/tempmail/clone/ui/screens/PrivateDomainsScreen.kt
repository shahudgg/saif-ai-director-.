package com.tempmail.clone.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tempmail.clone.ui.AppViewModel
import com.tempmail.clone.ui.components.AppToolbar

/**
 * Private domains — mirrors `fragment_private_domains.xml` +
 * `dialog_add_domain.xml` + `dialog_dns_settings.xml`.
 * Requires Premium; uses the RPC domain.get / domain.add / domain.delete.
 */
@Composable
fun PrivateDomainsScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit,
    onPremium: () -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var addOpen by remember { mutableStateOf(false) }
    var dnsDomain by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(state.isPremium) {
        if (state.isPremium) viewModel.refreshPrivateDomains()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        AppToolbar(title = "Private Domains", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp)) {
            if (!state.isPremium) {
                Text("Available on Premium", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "The private domains belong to your account only. You can easily add it by changing DNS(MX) settings.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                Button(onClick = onPremium) { Text("Upgrade to Premium") }
                return@Column
            }

            Text(
                "The private domains belong to your account only. You can easily add it by changing DNS(MX) settings.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { addOpen = true }) { Text("Add private domain") }
            Spacer(Modifier.height(16.dp))

            if (state.privateDomains.isEmpty()) {
                Text("You have not private domains", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.privateDomains, key = { it.domain }) { domain ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp))
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Icon(Icons.Filled.Domain, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(domain.domain, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "Status: ${domain.status ?: "pending"}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            TextButton(onClick = { dnsDomain = domain.domain }) { Text("DNS") }
                            IconButton(onClick = { viewModel.removePrivateDomain(domain.domain) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (addOpen) {
        var value by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addOpen = false },
            title = { Text("Add private domains") },
            text = {
                Column {
                    Text("Enter domain ( e.g. domain.com)", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = value,
                        onValueChange = { value = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (value.isNotBlank()) viewModel.addPrivateDomain(value.trim())
                        addOpen = false
                    },
                ) { Text("Add domains") }
            },
            dismissButton = { TextButton(onClick = { addOpen = false }) { Text("Cancel") } },
        )
    }

    dnsDomain?.let { domain ->
        AlertDialog(
            onDismissRequest = { dnsDomain = null },
            title = { Text("DNS settings") },
            text = {
                Column {
                    Text("To enable your private domain, please follow this steps", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    DnsStep("Step 1:", "Sign in to your domain registrar and go to the DNS management section")
                    DnsStep("Step 2:", "Delete any existing MX settings")
                    DnsStep("Step 3:", "Add MX record:  mx1.mailhost-12.net")
                    Spacer(Modifier.height(8.dp))
                    Text(domain, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
            },
            confirmButton = { TextButton(onClick = { dnsDomain = null }) { Text("Verify settings") } },
            dismissButton = { TextButton(onClick = { dnsDomain = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun DnsStep(step: String, text: String) {
    Row(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(step, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.size(6.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}
