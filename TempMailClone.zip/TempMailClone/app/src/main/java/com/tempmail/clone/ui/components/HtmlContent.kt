package com.tempmail.clone.ui.components

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Minimal HTML renderer standing in for the original `WrapContentWebView`.
 * Renders the email body; javascript is disabled for safety.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HtmlContent(
    html: String,
    modifier: Modifier = Modifier,
) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                webViewClient = WebViewClient()
                settings.javaScriptEnabled = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.defaultTextEncodingName = "utf-8"
                settings.textZoom = 100
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            }
        },
        update = { webView ->
            val document = if (html.contains("<html", ignoreCase = true)) {
                html
            } else {
                "<html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"></head>" +
                    "<body style=\"margin:0;padding:12px;font-family:sans-serif;font-size:15px;\">$html</body></html>"
            }
            webView.loadDataWithBaseURL(null, document, "text/html", "utf-8", null)
        },
    )
}
