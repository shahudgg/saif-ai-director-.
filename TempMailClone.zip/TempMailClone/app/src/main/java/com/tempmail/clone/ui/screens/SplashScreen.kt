package com.tempmail.clone.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.tempmail.clone.R
import com.tempmail.clone.ui.anim.MotionTiming
import kotlinx.coroutines.delay

/**
 * Mirrors `activity_splash.xml` + `splash_screen_view.xml`: a 300dp logo
 * centred on the grey `main_background`.
 *
 * The system splash icon (AndroidX SplashScreen, theme `Theme.App.Starting`)
 * scales up as it settles; the clone reproduces that with a 400ms
 * `scale 0.6 → 1.0` before the 900ms hold elapses.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val scale = remember { Animatable(0.6f) }
    LaunchedEffect(Unit) {
        scale.animateTo(1f, tween(MotionTiming.SPLASH_LOGO_MS, easing = MotionTiming.EaseOutCubic))
        delay(MotionTiming.SPLASH_MS)
        onFinished()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.ic_launcher_foreground),
            contentDescription = null,
            modifier = Modifier
                .size(300.dp)
                .graphicsLayer {
                    scaleX = scale.value
                    scaleY = scale.value
                    alpha = (scale.value - 0.4f) / 0.6f
                },
        )
    }
}
