package com.tempmail.clone.data.repository

import com.tempmail.clone.data.local.DomainEntity
import com.tempmail.clone.data.local.EmailEntity
import com.tempmail.clone.data.remote.model.DomainExpire
import com.tempmail.clone.data.remote.model.ExtendedMail
import com.tempmail.clone.data.remote.model.MailFree
import com.tempmail.clone.data.remote.model.PremiumMailInbox

/** Convert the free `/messages` payload into a Room [EmailEntity]. */
fun MailFree.toEntity(mailbox: String): EmailEntity = EmailEntity(
    eid = mailId,
    emailAddress = mailbox,
    isChecked = false,
    fromField = mailFrom,
    subject = mailSubject,
    timestampMs = (mailTimestamp * 1000L).toLong(),
    isDeleted = false,
    preview = preview ?: mailHtml.replace(Regex("<[^>]+>"), " ").trim().take(200),
    isDetailsLoaded = true,
    attachmentsCount = attachmentsCount,
)

/** Convert a premium inbox row (mailbox.listv2) into a Room [EmailEntity]. */
fun PremiumMailInbox.toEntity(mailbox: String): EmailEntity = EmailEntity(
    eid = mailId ?: "",
    emailAddress = mailbox,
    isChecked = false,
    fromField = mailFrom,
    subject = mailSubject,
    timestampMs = (mailTimestamp * 1000L).toLong(),
    isDeleted = false,
    preview = preview ?: mailHtml?.replace(Regex("<[^>]+>"), " ")?.trim()?.take(200),
    isDetailsLoaded = false,
    attachmentsCount = attachmentsCount,
)

/** Convert a premium message (mail.get) into a Room [EmailEntity]. */
fun ExtendedMail.toEntity(mailbox: String): EmailEntity = EmailEntity(
    eid = mailId ?: "",
    emailAddress = mailbox,
    isChecked = true,
    fromField = mailFrom,
    subject = mailSubject,
    timestampMs = (mailTimestamp * 1000L).toLong(),
    isDeleted = false,
    preview = preview ?: mailTextOnly?.take(200),
    isDetailsLoaded = true,
    attachmentsCount = if (attachmentsCount > 0) attachmentsCount else (attachmentInfo?.size ?: 0),
)

fun DomainExpire.toEntity(isPrivate: Boolean): DomainEntity = DomainEntity(
    domain = domain ?: "",
    expirationTimestamp = exp ?: 0L,
    type = if (isPrivate) "private" else (type ?: "premium"),
    status = status,
)
