package com.tempmail.clone.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.tempmail.clone.ui.components.AppToolbar
import com.tempmail.clone.util.Constants

/**
 * Web Premium / QR pairing — mirrors `fragment_qr_code.xml` +
 * `ui.scan.*`. Shows a QR linking to the desktop site; the original opened the
 * `temp-mail.org/premium` login and paired the account.
 */
@Composable
fun QrScreen(onBack: () -> Unit, onPremium: () -> Unit) {
    val bitmap = remember { generateQr("${Constants.URL_WEB_PREMIUM}/premium") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        AppToolbar(title = "Scan QR-code", onBack = onBack)
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("Web Premium", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(10.dp))
            Text(
                "Go to \"Web Premium\", scan the QR code, and log in to access Premium features on https://temp-mail.org",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "QR code",
                    modifier = Modifier
                        .size(220.dp)
                        .background(androidx.compose.ui.graphics.Color.White),
                )
            }
            Spacer(Modifier.height(24.dp))
            Button(onClick = onPremium) { Text("Open Premium") }
        }
    }
}

private fun generateQr(content: String): Bitmap? = try {
    val size = 512
    val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    for (x in 0 until size) {
        for (y in 0 until size) {
            bmp.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
    bmp
} catch (t: Throwable) {
    null
}
