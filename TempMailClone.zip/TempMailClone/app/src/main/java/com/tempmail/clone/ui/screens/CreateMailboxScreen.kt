package com.tempmail.clone.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tempmail.clone.ui.AppViewModel
import com.tempmail.clone.ui.components.AppToolbar
import com.tempmail.clone.util.Constants

/**
 * Custom email address dialog — mirrors `dialog_new_email.xml` /
 * `ui.createMailbox.CreateMailboxDialog`. Requires Premium (premium domains).
 */
@Composable
fun CreateMailboxScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit,
    onPremium: () -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var local by remember { mutableStateOf("") }
    var domain by remember { mutableStateOf(state.domains.firstOrNull()?.domain ?: "") }
    var domainOpen by remember { mutableStateOf(false) }

    val reserved = Constants.RESERVED_NAMES.contains(local.lowercase())
    val valid = local.isNotBlank() && !reserved && domain.isNotBlank()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        AppToolbar(title = "Custom Email Address", onBack = onBack)

        Column(modifier = Modifier.padding(20.dp)) {
            if (!state.isPremium) {
                Text(
                    text = "Available on Premium",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Custom and multiple mailboxes require a Premium account.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                Button(onClick = onPremium) { Text("Upgrade to Premium") }
                return@Column
            }

            Text("Enter name", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = local,
                onValueChange = { local = it.filter { c -> c.isLetterOrDigit() || c == '.' || c == '_' || c == '-' } },
                singleLine = true,
                isError = reserved,
                supportingText = {
                    if (reserved) Text("This name is reserved")
                },
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(16.dp))
            Text("Choose domain", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(6.dp))
            Box {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                        .clickable { domainOpen = true }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(domain.ifBlank { "Select a domain" }, modifier = Modifier.weight(1f))
                }
                DropdownMenu(expanded = domainOpen, onDismissRequest = { domainOpen = false }) {
                    state.domains.forEach { d ->
                        DropdownMenuItem(
                            text = { Text(d.domain) },
                            onClick = {
                                domain = d.domain
                                domainOpen = false
                            },
                        )
                    }
                    if (state.domains.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("No premium domains loaded") },
                            onClick = { domainOpen = false },
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { viewModel.createCustomMailbox(local, domain); onBack() },
                enabled = valid,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
            ) {
                Text("Create New Address")
            }
        }
    }
}
