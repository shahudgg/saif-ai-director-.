package com.tempmail.clone

import android.app.Application
import com.tempmail.clone.data.local.AppDatabase
import com.tempmail.clone.data.local.PreferenceManager
import com.tempmail.clone.data.remote.NetworkModule
import com.tempmail.clone.data.repository.DomainsRepository
import com.tempmail.clone.data.repository.InboxRepository
import com.tempmail.clone.data.repository.MailRepository
import com.tempmail.clone.data.repository.MailboxRepository
import com.tempmail.clone.data.repository.SubscriptionRepository

/**
 * Manual service locator (the clone avoids Hilt so it builds with fewer
 * moving parts; the original used Hilt/Dagger).
 */
class AppContainer(application: Application) {
    val database: AppDatabase = AppDatabase.get(application)
    val preferences: PreferenceManager = PreferenceManager(application)

    val mailboxRepository: MailboxRepository = MailboxRepository(
        freeApi = NetworkModule.freeApi,
        premiumApi = NetworkModule.premiumApi,
        mailboxDao = database.mailboxDao(),
        prefs = preferences,
    )
    val inboxRepository: InboxRepository = InboxRepository(
        freeApi = NetworkModule.freeApi,
        premiumApi = NetworkModule.premiumApi,
        emailDao = database.emailDao(),
        prefs = preferences,
    )
    val mailRepository: MailRepository = MailRepository(
        freeApi = NetworkModule.freeApi,
        premiumApi = NetworkModule.premiumApi,
        emailDao = database.emailDao(),
        prefs = preferences,
    )
    val domainsRepository: DomainsRepository = DomainsRepository(
        premiumApi = NetworkModule.premiumApi,
        domainDao = database.domainDao(),
        prefs = preferences,
    )
    val subscriptionRepository: SubscriptionRepository = SubscriptionRepository(
        premiumApi = NetworkModule.premiumApi,
        prefs = preferences,
    )
}

class App : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
