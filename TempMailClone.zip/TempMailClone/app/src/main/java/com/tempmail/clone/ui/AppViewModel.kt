package com.tempmail.clone.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tempmail.clone.App
import com.tempmail.clone.data.local.DomainEntity
import com.tempmail.clone.data.local.EmailEntity
import com.tempmail.clone.data.local.MailboxEntity
import com.tempmail.clone.util.Resource
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Single shared state holder for every screen (mirrors the original's many ViewModels). */
data class UiState(
    val onboarded: Boolean? = null,
    val isPremium: Boolean = false,
    val darkMode: Boolean? = null,
    val animations: Boolean = true,
    val notifications: Boolean = true,
    val autofill: Boolean = false,
    val language: String? = null,
    val mailbox: MailboxEntity? = null,
    val mailboxes: List<MailboxEntity> = emptyList(),
    val emails: List<EmailEntity> = emptyList(),
    val unreadCount: Int = 0,
    val domains: List<DomainEntity> = emptyList(),
    val privateDomains: List<DomainEntity> = emptyList(),
    val loading: Boolean = false,
    val refreshing: Boolean = false,
)

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as App).container
    private val prefs = container.preferences
    private val mailboxRepo = container.mailboxRepository
    private val inboxRepo = container.inboxRepository
    private val domainsRepo = container.domainsRepository

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        viewModelScope.launch {
            prefs.onboarded.collect { v -> _state.update { it.copy(onboarded = v) } }
        }
        collectFlows()
        viewModelScope.launch { bootstrap() }
    }

    private fun collectFlows() {
        viewModelScope.launch { prefs.isPremium.collect { v -> _state.update { it.copy(isPremium = v) } } }
        viewModelScope.launch { prefs.darkMode.collect { v -> _state.update { it.copy(darkMode = v) } } }
        viewModelScope.launch { prefs.animations.collect { v -> _state.update { it.copy(animations = v ?: true) } } }
        viewModelScope.launch { prefs.notifications.collect { v -> _state.update { it.copy(notifications = v) } } }
        viewModelScope.launch { prefs.autofill.collect { v -> _state.update { it.copy(autofill = v) } } }
        viewModelScope.launch { prefs.language.collect { v -> _state.update { it.copy(language = v?.ifBlank { null }) } } }
        viewModelScope.launch { mailboxRepo.observeDefault().collect { v -> _state.update { it.copy(mailbox = v) } } }
        viewModelScope.launch { mailboxRepo.observeMailboxes().collect { v -> _state.update { it.copy(mailboxes = v) } } }
        viewModelScope.launch { domainsRepo.observeDomains().collect { v -> _state.update { it.copy(domains = v) } } }
        viewModelScope.launch { domainsRepo.observePrivateDomains().collect { v -> _state.update { it.copy(privateDomains = v) } } }
        viewModelScope.launch {
            mailboxRepo.observeDefault().collectLatest { mailbox ->
                if (mailbox == null) {
                    _state.update { it.copy(emails = emptyList(), unreadCount = 0) }
                    return@collectLatest
                }
                launch { inboxRepo.observeEmails(mailbox.fullEmailAddress).collect { list -> _state.update { it.copy(emails = list) } } }
                launch { inboxRepo.observeUnread(mailbox.fullEmailAddress).collect { count -> _state.update { it.copy(unreadCount = count) } } }
            }
        }
    }

    private suspend fun bootstrap() {
        val onboarded = prefs.onboarded.first()
        if (!onboarded) return
        if (mailboxRepo.current() == null) {
            createNewMailbox()
        } else {
            refreshInbox()
        }
    }

    fun completeOnboarding() = viewModelScope.launch { prefs.setOnboarded(true) }

    /** Create / replace the current mailbox (free "Change" button). */
    fun createNewMailbox(domain: String? = null) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val result = if (_state.value.isPremium) {
                mailboxRepo.createNewMailboxPremium(mailboxRepo.randomLocalPart(), domain ?: "")
            } else {
                mailboxRepo.createNewMailboxFree()
            }
            _state.update { it.copy(loading = false) }
            when (result) {
                is Resource.Success -> {
                    _messages.tryEmit("New address created")
                    refreshInbox()
                }
                is Resource.Error -> _messages.tryEmit(result.error.message ?: "Could not create address")
                Resource.Loading -> Unit
            }
        }
    }

    /** Create a premium mailbox with a chosen local part + domain. */
    fun createCustomMailbox(local: String, domain: String) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val result = mailboxRepo.createNewMailboxPremium(local, domain)
            _state.update { it.copy(loading = false) }
            when (result) {
                is Resource.Success -> {
                    _messages.tryEmit("Mailbox created")
                    refreshInbox()
                }
                is Resource.Error -> _messages.tryEmit(result.error.message ?: "Could not create mailbox")
                Resource.Loading -> Unit
            }
        }
    }

    fun refreshInbox() {
        val mailbox = _state.value.mailbox ?: return
        viewModelScope.launch {
            _state.update { it.copy(refreshing = true) }
            inboxRepo.refresh(mailbox.fullEmailAddress, isPremium = _state.value.isPremium)
            _state.update { it.copy(refreshing = false) }
        }
    }

    fun switchMailbox(mailbox: MailboxEntity) {
        viewModelScope.launch {
            mailboxRepo.setDefault(mailbox)
            refreshInbox()
        }
    }

    fun deleteMailbox(mailbox: MailboxEntity) {
        viewModelScope.launch {
            when (val result = mailboxRepo.delete(mailbox)) {
                is Resource.Success -> {
                    _messages.tryEmit("Mailbox deleted")
                    if (mailboxRepo.current() == null) createNewMailbox()
                }
                is Resource.Error -> _messages.tryEmit(result.error.message ?: "Delete failed")
                Resource.Loading -> Unit
            }
        }
    }

    fun deleteEmail(email: EmailEntity) {
        viewModelScope.launch {
            inboxRepo.markDeleted(email)
            _messages.tryEmit("Message deleted")
        }
    }

    fun toggleRead(email: EmailEntity) = viewModelScope.launch { inboxRepo.toggleReadStatus(email) }

    fun openEmail(email: EmailEntity) = viewModelScope.launch { inboxRepo.setChecked(email.eid, true) }

    // ---- Settings -----------------------------------------------------------
    fun setDarkMode(value: Boolean) = viewModelScope.launch { prefs.setDarkMode(value) }
    fun setAnimations(value: Boolean) = viewModelScope.launch { prefs.setAnimations(value) }
    fun setNotifications(value: Boolean) = viewModelScope.launch { prefs.setNotifications(value) }
    fun setAutofill(value: Boolean) = viewModelScope.launch { prefs.setAutofill(value) }
    fun setLanguage(value: String?) = viewModelScope.launch { prefs.setLanguage(value) }
    fun setPremium(value: Boolean) = viewModelScope.launch { prefs.setPremium(value) }

    // ---- Domains ------------------------------------------------------------
    fun refreshPrivateDomains() = viewModelScope.launch { domainsRepo.fetchPrivateDomains() }

    fun addPrivateDomain(domain: String) {
        viewModelScope.launch {
            when (val result = domainsRepo.addPrivateDomain(domain)) {
                is Resource.Success -> _messages.tryEmit("Domain added")
                is Resource.Error -> _messages.tryEmit(result.error.message ?: "Could not add domain")
                Resource.Loading -> Unit
            }
        }
    }

    fun removePrivateDomain(domain: String) {
        viewModelScope.launch {
            when (val result = domainsRepo.removePrivateDomain(domain)) {
                is Resource.Success -> _messages.tryEmit("Domain removed")
                is Resource.Error -> _messages.tryEmit(result.error.message ?: "Could not remove domain")
                Resource.Loading -> Unit
            }
        }
    }

    // ---- Mail ---------------------------------------------------------------
    suspend fun loadMailBody(email: EmailEntity): Resource<String> =
        container.mailRepository.loadBody(email, _state.value.isPremium)

    suspend fun loadMailSource(email: EmailEntity): Resource<String> =
        container.mailRepository.loadSource(email, _state.value.isPremium)

    val subscriptionPlans = container.subscriptionRepository.plans
    val premiumFeatures = container.subscriptionRepository.premiumFeatures
}
