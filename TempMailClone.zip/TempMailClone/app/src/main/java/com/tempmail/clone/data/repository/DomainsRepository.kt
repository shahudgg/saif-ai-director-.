package com.tempmail.clone.data.repository

import com.tempmail.clone.data.local.DomainDao
import com.tempmail.clone.data.local.DomainEntity
import com.tempmail.clone.data.local.PreferenceManager
import com.tempmail.clone.data.remote.PremiumApi
import com.tempmail.clone.data.remote.model.AddDomainBody
import com.tempmail.clone.data.remote.model.DeletePrivateDomainBody
import com.tempmail.clone.data.remote.model.DomainsBody
import com.tempmail.clone.data.remote.model.GetPrivateDomainBody
import com.tempmail.clone.util.ApiError
import com.tempmail.clone.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

/**
 * Domains (premium + private/custom). Ported from
 * `com.tempmail.data.repository.DomainsRepository`.
 * RPC: getdomains / domain.get / domain.add / domain.delete.
 */
class DomainsRepository(
    private val premiumApi: PremiumApi,
    private val domainDao: DomainDao,
    private val prefs: PreferenceManager,
) {
    fun observeDomains(): Flow<List<DomainEntity>> = domainDao.observeDomains()
    fun observePrivateDomains(): Flow<List<DomainEntity>> = domainDao.observePrivateDomains()
    suspend fun cachedDomains(): List<DomainEntity> = domainDao.domains()
    suspend fun cachedPrivateDomains(): List<DomainEntity> = domainDao.privateDomains()

    /** Premium domains available for mailbox creation. */
    suspend fun fetchPremiumDomains(): Resource<List<DomainEntity>> {
        val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
        return try {
            val response = premiumApi.getDomains(DomainsBody(sid))
            val wrapper = response.body()
            val error = wrapper?.error
            val domains = wrapper?.result?.domainsExp
            if (!response.isSuccessful || error != null || domains == null) {
                Resource.Error(ApiError(error?.code ?: response.code(), error?.message, error?.errorName, error?.subCode))
            } else {
                val entities = domains.map { it.toEntity(isPrivate = false) }.filter { it.domain.isNotBlank() }
                domainDao.upsertAll(entities)
                Resource.Success(entities)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    suspend fun fetchPrivateDomains(): Resource<List<DomainEntity>> {
        val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
        return try {
            val response = premiumApi.getPrivateDomains(GetPrivateDomainBody(sid))
            val wrapper = response.body()
            val error = wrapper?.error
            val domains = wrapper?.result?.domains
            if (!response.isSuccessful || error != null || domains == null) {
                Resource.Error(ApiError(error?.code ?: response.code(), error?.message, error?.errorName, error?.subCode))
            } else {
                val entities = domains.map {
                    DomainEntity(
                        domain = it.domain.orEmpty(),
                        type = "private",
                        status = it.status,
                    )
                }.filter { it.domain.isNotBlank() }
                domainDao.clearPrivate()
                domainDao.upsertAll(entities)
                Resource.Success(entities)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    suspend fun addPrivateDomain(domain: String): Resource<DomainEntity> {
        val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
        return try {
            val response = premiumApi.addPrivateDomain(AddDomainBody(sid, domain))
            val wrapper = response.body()
            val error = wrapper?.error
            val added = wrapper?.result
            if (!response.isSuccessful || error != null || added == null) {
                Resource.Error(ApiError(error?.code ?: response.code(), error?.message, error?.errorName, error?.subCode))
            } else {
                val entity = DomainEntity(domain = added.domain ?: domain, type = "private", status = added.status)
                domainDao.upsertAll(listOf(entity))
                Resource.Success(entity)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }

    suspend fun removePrivateDomain(domain: String): Resource<Unit> {
        val sid = prefs.sid.first() ?: return Resource.Error(ApiError(401, "Premium session required"))
        return try {
            val response = premiumApi.deletePrivateDomain(DeletePrivateDomainBody(sid, domain))
            val wrapper = response.body()
            val error = wrapper?.error
            if (!response.isSuccessful || error != null) {
                Resource.Error(ApiError(error?.code ?: response.code(), error?.message))
            } else {
                domainDao.delete(domain)
                Resource.Success(Unit)
            }
        } catch (t: Throwable) {
            Resource.Error(ApiError(message = t.message))
        }
    }
}
