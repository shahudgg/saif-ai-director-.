
2*/storage/emulated/0/MT2/apks/TempMailClone1793434284088"�
(gradle/wrapper/gradle-wrapper.propertiesS/storage/emulated/0/MT2/apks/TempMailClone/gradle/wrapper/gradle-wrapper.properties� �Ǟ�4*@d7010368a34c1c06df2bae1a85d8b24c39b2499c74ac892fc7e66d005dbd7b8a"�
app/build.gradle.kts?/storage/emulated/0/MT2/apks/TempMailClone/app/build.gradle.kts� ����4*@44dbbf52ed8f10d2b17c0bbfa990f1c798b4020e8229f7a7c003df4592c47931"�
settings.gradle.kts>/storage/emulated/0/MT2/apks/TempMailClone/settings.gradle.kts� �ϟ�4*@4139832f66feecf28738e550eacf5a77733644a67a1908d44b725fcca1082e8a"�
build.gradle.kts;/storage/emulated/0/MT2/apks/TempMailClone/build.gradle.kts� �ϟ�4*@274f29df4ac3e283a248c9295e34f90084f12576b0b243130fd457780ea54501"�
gradle.properties</storage/emulated/0/MT2/apks/TempMailClone/gradle.properties� �ϟ�4*@c4f652374b7191a2a8ce81e72790ceb36098b28969c47f15418a1b399221b422*�
E/storage/emulated/0/MT2/apks/TempMailClone/.cg/gradle-sync/project.pb@7ca42302d5e9dd08ab79cea318d1496c2c2d98be4d0b6617a99a7b52fb236da7